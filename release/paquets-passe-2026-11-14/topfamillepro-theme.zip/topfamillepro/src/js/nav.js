/**
 * Navigation : sous-menus desktop, menu mobile, barre de scroll du header.
 * Vanilla JS, sans dépendance. Chargé en `defer`.
 */
(function () {
  'use strict';

  var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

  /**
   * querySelectorAll(FOCUSABLE) matche aussi les liens des sous-menus accordéon repliés
   * (`[hidden]`, donc `display:none`) : un `.focus()` sur un tel élément échoue silencieusement,
   * ce qui casse le piège de focus dans les deux sens dès qu'un accordéon est fermé.
   * `offsetParent === null` exclut fiablement ce qui n'est pas réellement rendu (mais pas les
   * éléments `position: fixed`, ce que n'est aucun des liens ici, seul le conteneur du panneau
   * l'est).
   */
  function visibleFocusable(container) {
    return Array.prototype.filter.call(container.querySelectorAll(FOCUSABLE), function (el) {
      return el.offsetParent !== null;
    });
  }

  function trapFocus(container, event) {
    var focusable = visibleFocusable(container);
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  /* ---------- Header : ombre au scroll ---------- */
  function initHeaderScroll() {
    var header = document.querySelector('[data-tfp-header]');
    if (!header) return;
    var onScroll = function () {
      header.classList.toggle('tfp-header--scrolled', window.scrollY > 4);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Sous-menus desktop (Prestations, Zones) ---------- */
  function initDesktopSubmenus() {
    var toggles = document.querySelectorAll('[data-tfp-submenu-toggle]');
    if (!toggles.length) return;

    function closeAll(exceptId) {
      toggles.forEach(function (btn) {
        var id = btn.getAttribute('aria-controls');
        if (id === exceptId) return;
        var panel = document.getElementById(id);
        btn.setAttribute('aria-expanded', 'false');
        var lien = btn.parentNode && btn.parentNode.querySelector('.tfp-nav__link--parent[aria-expanded]');
        if (lien) lien.setAttribute('aria-expanded', 'false');
        if (panel) panel.hidden = true;
      });
    }

    toggles.forEach(function (btn) {
      var id = btn.getAttribute('aria-controls');
      var panel = document.getElementById(id);
      if (!panel) return;

      function basculer() {
        var expanded = btn.getAttribute('aria-expanded') === 'true';
        closeAll(expanded ? null : id);
        btn.setAttribute('aria-expanded', String(!expanded));
        if (libelle) libelle.setAttribute('aria-expanded', String(!expanded));
        panel.hidden = expanded;
      }

      /*
       * Décision du 13 novembre 2026 : un clic sur « Prestations » ou « Zones d'intervention »
       * OUVRE les choix, il ne quitte plus la page. Le libellé reste un lien dans le HTML — sans
       * JavaScript il mène toujours à sa page, et le lien compte pour le référencement — mais,
       * script chargé, il devient LA commande de dépliage : rôle bouton, état annoncé. Le chevron,
       * devenu redondant, sort de l'ordre de tabulation. La page du libellé reste accessible :
       * c'est la première entrée du panneau.
       */
      var groupe = btn.closest('[data-tfp-nav-item]');
      var libelle = groupe && groupe.querySelector('.tfp-nav__link--parent');
      if (libelle) {
        libelle.setAttribute('role', 'button');
        libelle.setAttribute('aria-expanded', 'false');
        libelle.setAttribute('aria-controls', id);
        btn.setAttribute('tabindex', '-1');
        btn.setAttribute('aria-hidden', 'true');
        libelle.addEventListener('click', function (event) {
          event.preventDefault();
          basculer();
        });
        libelle.addEventListener('keydown', function (event) {
          if (event.key === ' ') {
            event.preventDefault();
            basculer();
          }
        });
      }

      btn.addEventListener('click', basculer);
    });

    document.addEventListener('click', function (event) {
      if (!(event.target instanceof Element)) return;
      if (!event.target.closest('[data-tfp-nav-item]')) closeAll(null);
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        var wasOpen = Array.prototype.some.call(toggles, function (b) {
          return b.getAttribute('aria-expanded') === 'true';
        });
        closeAll(null);
        if (wasOpen) {
          var openBtn = document.activeElement && document.activeElement.closest('[data-tfp-nav-item]');
          if (openBtn) (openBtn.querySelector('.tfp-nav__link--parent[role="button"]') || openBtn.querySelector('[data-tfp-submenu-toggle]')).focus();
        }
      }
    });
  }

  /* ---------- Menu mobile ---------- */
  function initMobileMenu() {
    var openBtn = document.querySelector('[data-tfp-mobile-open]');
    var closeBtn = document.querySelector('[data-tfp-mobile-close]');
    var panel = document.querySelector('[data-tfp-mobile-panel]');
    if (!openBtn || !panel) return;

    var lastFocused = null;

    function open() {
      lastFocused = document.activeElement;
      panel.hidden = false;
      document.body.classList.add('tfp-scroll-locked');
      openBtn.setAttribute('aria-expanded', 'true');
      var closeTarget = closeBtn || visibleFocusable(panel)[0];
      if (closeTarget) closeTarget.focus();
      document.addEventListener('keydown', onKeydown);
    }

    function close(rendreFocus) {
      panel.hidden = true;
      document.body.classList.remove('tfp-scroll-locked');
      openBtn.setAttribute('aria-expanded', 'false');
      document.removeEventListener('keydown', onKeydown);
      if (rendreFocus !== false && lastFocused) lastFocused.focus();
    }

    /* Un lien suivi depuis le tiroir le referme : indispensable pour une ancre de la même page
       (retour au formulaire du devis), où aucun rechargement ne le ferait disparaître. Le focus
       n'est pas rendu au bouton du menu — il suit la navigation. */
    panel.addEventListener('click', function (event) {
      var lien = event.target.closest('a[href]');
      if (lien && !panel.hidden) close(false);
    });

    function onKeydown(event) {
      if (event.key === 'Escape') {
        close(true);
      } else if (event.key === 'Tab') {
        trapFocus(panel, event);
      }
    }

    openBtn.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', function () { close(); });

    /* Sous-menus accordéon à l'intérieur du panneau mobile */
    panel.querySelectorAll('[data-tfp-mobile-submenu-toggle]').forEach(function (btn) {
      var id = btn.getAttribute('aria-controls');
      var sub = document.getElementById(id);
      if (!sub) return;
      var libelle = btn.parentNode && btn.parentNode.querySelector('a.tfp-mobile-nav__link');
      function basculer() {
        var expanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!expanded));
        if (libelle) libelle.setAttribute('aria-expanded', String(!expanded));
        sub.hidden = expanded;
      }
      btn.addEventListener('click', basculer);
      // Même règle qu'en bureau (13 novembre 2026) : le libellé ouvre les choix au lieu de naviguer.
      if (libelle) {
        libelle.setAttribute('role', 'button');
        libelle.setAttribute('aria-expanded', 'false');
        libelle.setAttribute('aria-controls', id);
        btn.setAttribute('tabindex', '-1');
        btn.setAttribute('aria-hidden', 'true');
        libelle.addEventListener('click', function (event) {
          event.preventDefault();
          event.stopPropagation(); // le tiroir se ferme sur tout lien suivi : celui-ci ne l'est pas.
          basculer();
        });
        libelle.addEventListener('keydown', function (event) {
          if (event.key === ' ') { event.preventDefault(); basculer(); }
        });
      }
    });

    /* Ferme le panneau si on revient en desktop (redimensionnement) */
    var mq = window.matchMedia('(min-width: 820px)');
    var onChange = function (e) {
      if (e.matches && !panel.hidden) close();
    };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
  }

  /**
   * Cale la hauteur du réservataire (.tfp-mobile-cta-spacer) sur la hauteur réelle de la barre
   * CTA mobile fixe : une valeur figée en CSS peut être décalée de quelques dixièmes de pixel
   * selon le rendu des polices, laissant apparaître un chevauchement infime avec le footer.
   */
  function syncMobileCtaBarSpacer() {
    var bar = document.querySelector('.tfp-mobile-cta-bar');
    var spacer = document.querySelector('.tfp-mobile-cta-spacer');
    if (!bar || !spacer) return;

    var sync = function () {
      var isVisible = window.getComputedStyle(bar).display !== 'none';
      spacer.style.height = isVisible ? Math.ceil(bar.getBoundingClientRect().height) + 'px' : '0px';
    };

    sync();
    window.addEventListener('resize', sync);
    if (window.ResizeObserver) {
      new ResizeObserver(sync).observe(bar);
    }
  }

  /**
   * Volets du pied de page (<details data-tfp-volet>) : rendus ouverts côté serveur, repliés sous
   * 820 px, maintenus ouverts au-delà (ce sont alors des colonnes, rien ne doit se replier).
   */
  function initFooterVolets() {
    var volets = document.querySelectorAll('[data-tfp-volet]');
    if (!volets.length || !window.matchMedia) return;
    var mobile = window.matchMedia('(max-width: 819px)');
    var appliquer = function () {
      volets.forEach(function (d) { d.open = !mobile.matches; });
    };
    appliquer();
    if (mobile.addEventListener) mobile.addEventListener('change', appliquer);
    volets.forEach(function (d) {
      d.addEventListener('toggle', function () {
        if (!mobile.matches && !d.open) d.open = true;
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initHeaderScroll();
    initFooterVolets();
    initDesktopSubmenus();
    initMobileMenu();
    syncMobileCtaBarSpacer();
  });
})();

<?php
/**
 * Composant commun de rendu des pages statiques narratives.
 *
 * Ces pages sont des pages WordPress classiques (CLAUDE.md §3), sans champs ACF : leur contenu vit
 * dans une option par page, produite par tools/generate-pages.mjs depuis la maquette Claude
 * Design. Un seul composant les rend toutes, ce qui évite dix gabarits qui divergeraient à la
 * première correction, et garde l'ordre des sections figé.
 *
 * Les routes internes de la maquette (`#/…`) ne sont jamais servies telles quelles : elles sont
 * traduites en URL WordPress réelles à l'affichage. Une route sans équivalent n'est pas rendue en
 * lien mort — son libellé reste du texte (CLAUDE.md §8).
 *
 * @var array $args {
 *     @type string $key   Clé de page (`pourquoi-nous`, `a-propos`…).
 *     @type array  $skip  Index de sections à ne pas rendre (déjà couvertes par le gabarit).
 *     @type array  $liens Redirections `route relevée => URL réelle`, quand une règle du projet
 *                         impose une destination autre que celle du prototype.
 * }
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data = tfp_static_page_data( $args['key'] ?? '' );
if ( empty( $data['sections'] ) ) {
	return;
}
$skip = $args['skip'] ?? array();
/*
 * Plage d'index à rendre, bornes comprises. Sert aux gabarits qui insèrent une bande à la main
 * AU MILIEU du flux : ils appellent le composant deux fois, avant puis après. Sans cela, la bande
 * ajoutée ne peut atterrir qu'en fin de page — c'est exactement ce qui déplaçait la bande
 * « Cahier des charges, intervenants et suivi » du pilier de la 11ᵉ à la 18ᵉ position.
 */
$index_min = isset( $args['de'] ) ? (int) $args['de'] : null;
$index_max = isset( $args['a'] ) ? (int) $args['a'] : null;
/*
 * Redirections de liens relevés → URL réelles, déclarées par le gabarit appelant (G26 §5).
 * Clé : la route telle qu'elle a été relevée sur la maquette. Voir le `case 'link'` plus bas.
 */
$liens_rediriges = is_array( $args['liens'] ?? null ) ? $args['liens'] : array();
/*
 * Sections REPLIÉES (passe commerciale du 10 novembre 2026, §4) : leur contenu passe dans un
 * <details> natif dont le résumé porte le titre du premier bloc, en H2. Le titre d'origine de ce
 * bloc n'est alors pas répété dans le corps. Tout reste dans le HTML, sans JavaScript.
 * Chaque section rendue reçoit aussi une ancre `s-{index}`, que tfp_static_sommaire() vise.
 */
$replier = array_map( 'intval', (array) ( $args['replier'] ?? array() ) );

foreach ( $data['sections'] as $section ) {
	if ( in_array( $section['index'], $skip, true ) ) {
		continue;
	}
	if ( null !== $index_min && (int) $section['index'] < $index_min ) {
		continue;
	}
	if ( null !== $index_max && (int) $section['index'] > $index_max ) {
		continue;
	}
	$classes = array( 'tfp-section--tight' );
	if ( 'centre' === ( $section['alignement'] ?? '' ) ) {
		// Bande centrée sur la maquette (appels finaux à fond primaire) — relevé, jamais déduit.
		$classes[] = 'tfp-section--centre';
	}
	if ( 'turquoise' === $section['fond'] ) {
		$classes[] = 'tfp-section--turquoise';
	} elseif ( 'navy' === $section['fond'] ) {
		$classes[] = 'tfp-section--navy';
	} elseif ( 'primary' === $section['fond'] ) {
		$classes[] = 'tfp-section--primary';
	} elseif ( 'alt' === $section['fond'] ) {
		$classes[] = 'tfp-section--alt';
	} elseif ( 'glacier' === $section['fond'] ) {
		$classes[] = 'tfp-section--glacier';
	} elseif ( 'blanc' === $section['fond'] ) {
		// La maquette alterne bandes blanches et bandes sur le fond de page. Le fond blanc était
		// relevé mais jamais rendu : l'alternance disparaissait, et avec elle la lecture par bandes.
		$classes[] = 'tfp-section--blanc';
	}

	/*
	 * Rembourrage vertical relevé sur la bande du prototype. Le thème en posait 52 px partout ; la
	 * maquette en pose 84 sur la plupart de ses bandes, 72 ou 48 sur d'autres. Ce n'est pas un
	 * rembourrage de compensation destiné à atteindre un ratio : c'est la valeur mesurée, passée en
	 * variable pour rester administrable et ne pas produire de style en ligne page par page.
	 */
	/*
	 * Le filtre employé ici effaçait les parenthèses et les virgules : `clamp(44px, 6vw, 80px)`
	 * devenait « clamp44px 6vw 80px », valeur invalide que le navigateur jette. Le relevé pouvait
	 * donc être juste sans jamais atteindre la page. `tfp_longueur_css()` — le filtre strict posé en
	 * G07 — admet les fonctions de longueur et refuse la valeur entière au moindre caractère hors
	 * jeu, ce qui est la bonne garantie sans être destructif.
	 */
	$pad = array();
	foreach ( array( 'padding_haut' => '--tfp-bande-haut', 'padding_bas' => '--tfp-bande-bas' ) as $cle => $var ) {
		$valeur = tfp_longueur_css( $section[ $cle ] ?? '' );
		if ( '' !== $valeur ) {
			$pad[] = $var . ':' . $valeur;
		}
	}
	/*
	 * Largeur de la colonne de lecture, relevée sur les paragraphes de la bande du prototype.
	 * Le thème laissait le texte occuper toute la largeur du conteneur : une ligne plus large tient
	 * plus de mots, donc moins de lignes, et chaque paragraphe perdait un tiers de sa hauteur. Les
	 * grilles de cartes ne sont pas concernées — elles gardent toute la largeur.
	 */
	$largeur = (int) ( $section['largeur_texte'] ?? 0 );
	if ( $largeur >= 400 && $largeur <= 1400 ) {
		$pad[] = '--tfp-bande-texte:' . $largeur . 'px';
	}
	/*
	 * Largeur du CONTENEUR de la bande, distincte de la colonne de lecture ci-dessus.
	 *
	 * Le prototype resserre certaines bandes à 900 ou 1040 px quand le thème applique partout son
	 * conteneur de 1260. La colonne de lecture ne peut pas y suppléer : elle borne le texte, pas les
	 * grilles. À 1440 px, une rangée de trois cartes de 264 px dans 900 px devient une rangée de
	 * quatre cartes de 285 px dans 1260, et la bande perd 345 px de haut.
	 *
	 * `--container-max` est la variable que `.tfp-container` lit déjà : la poser sur la bande suffit,
	 * sans règle nouvelle et sans sélecteur par URL.
	 */
	$largeur_conteneur = (int) ( $section['largeur_conteneur'] ?? 0 );
	if ( $largeur_conteneur >= 600 && $largeur_conteneur <= 1400 ) {
		$pad[] = '--container-max:' . $largeur_conteneur . 'px';
	}
	$pad_style = $pad ? ' style="' . esc_attr( implode( ';', $pad ) ) . '"' : '';
	/*
	 * Nombre de colonnes : relevé sur le rendu de la maquette par tools/generate-pages.mjs, et non
	 * deviné d'après la longueur des blocs. L'heuristique précédente (« plusieurs blocs courts ⇒
	 * colonnes ») se trompait notamment sur « Qui nous sommes » de /a-propos/, que la maquette
	 * empile sur toute la largeur.
	 *
	 * Le `?:` couvre les contenus produits avant l'ajout du champ : sans valeur relevée, on empile,
	 * ce qui reste lisible — l'inverse ne l'est pas.
	 */
	$colonnes = max( 1, min( 4, (int) ( $section['colonnes'] ?? 1 ) ) );

	/*
	 * Traitement en cartes : relevé lui aussi sur le rendu de la maquette, bande par bande. Le
	 * composant rendait tout en texte nu ; le prototype pose une partie de ces bandes dans des
	 * cartes blanches encadrées. À hauteur voisine, l'écran n'avait pas le même aspect.
	 */
	$carte = is_array( $section['cartes'] ?? null ) ? $section['cartes'] : null;

	/**
	 * Style d'un encadrement relevé : rembourrage et rayon viennent de la carte réelle.
	 *
	 * Ils vont de 20 à 32 px et de 12 à 18 px selon la bande ; en poser 32 partout allongeait
	 * /nettoyage-professionnel/ de 15 %.
	 */
	$carte_style_de = static function ( $c ) {
		if ( ! is_array( $c ) ) {
			return '';
		}
		$parts = array();
		foreach ( array( 'padding' => '--tfp-carte-padding', 'rayon' => '--tfp-carte-rayon', 'marge_bas' => '--tfp-carte-marge-bas' ) as $cle => $var ) {
			$valeur = tfp_longueur_css( $c[ $cle ] ?? '' );
			if ( '' !== $valeur ) {
				$parts[] = $var . ':' . $valeur;
			}
		}
		/*
		 * Fond de la carte — relevé mais jamais rendu jusqu'à G26 §5.
		 *
		 * Le panneau « Les étapes de candidature » de /recrutement/ est MARINE dans la maquette ;
		 * le thème le rendait blanc, et le parcours de candidature perdait le bloc qui le rend
		 * visible dans la page. Le relevé portait pourtant la couleur depuis le début : elle
		 * n'était simplement pas transmise. La valeur est filtrée sur une forme `rgb()`/`rgba()`
		 * stricte — elle vient de la base, elle ne peut pas être écrite telle quelle dans un style.
		 */
		if ( preg_match( '/^rgba?\([0-9, .]+\)$/', (string) ( $c['fond'] ?? '' ) ) ) {
			$parts[] = '--tfp-carte-fond:' . $c['fond'];
		}
		return implode( ';', $parts );
	};

	/**
	 * Une couleur relevée est-elle sombre ? Sert à basculer le texte en clair sur une carte foncée.
	 *
	 * Le contraste n'est pas une question de goût : du texte #18232D sur un fond #174A81 tombe
	 * sous le seuil de WCAG 2.2 AA. La bascule se décide donc sur la luminance mesurée, pas sur une
	 * liste de couleurs connues qui vieillirait mal.
	 */
	$carte_sombre = static function ( $c ) {
		if ( ! is_array( $c ) || ! preg_match( '/^rgba?\((\d+),\s*(\d+),\s*(\d+)/', (string) ( $c['fond'] ?? '' ), $m ) ) {
			return false;
		}
		return ( 0.299 * (int) $m[1] + 0.587 * (int) $m[2] + 0.114 * (int) $m[3] ) < 140;
	};

	/*
	 * La grille s'applique par rangée, pas à toute la bande : le prototype mêle couramment un bloc
	 * d'introduction sur toute la largeur et une rangée de cartes. Posée sur la bande entière, la
	 * grille rangeait l'introduction dans la première colonne, à côté des cartes.
	 */
	$sequences = tfp_static_runs( $section['blocs'] );
	?>
	<?php
	$est_repliee  = in_array( (int) $section['index'], $replier, true );
	$titre_repli  = $est_repliee ? trim( (string) ( $section['blocs'][0]['titre'] ?? '' ) ) : '';
	$est_repliee  = $est_repliee && '' !== $titre_repli;
	$titre_saute  = false;
	?>
	<section id="s-<?php echo (int) $section['index']; ?>" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"<?php echo $pad_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<div class="tfp-container">
		<?php if ( $est_repliee ) : ?>
			<details class="tfp-volet tfp-volet--section"><summary><h2><?php echo esc_html( $titre_repli ); ?></h2></summary><div class="tfp-volet__corps">
		<?php endif; ?>
		<?php
		foreach ( $sequences as $sequence ) :
			/*
			 * Le nombre de colonnes est celui de **cette rangée**, relevé sur le rendu, et non le
			 * maximum de la bande : une bande porte couramment une rangée de quatre cartes puis une
			 * rangée de trois, et prendre le maximum rangeait la seconde sur quatre colonnes dont une
			 * restait vide. `$colonnes` sert de repli pour les contenus produits avant ce relevé.
			 */
			$colonnes_rangee = max( 1, min( 4, (int) ( $sequence[0]['colonnes'] ?? $colonnes ) ) );
			$en_grille       = $colonnes_rangee > 1 && count( $sequence ) > 1 && ! empty( $sequence[0]['grille'] );

			/*
			 * Repli **intrinsèque** de la rangée, relevé sur le prototype.
			 *
			 * La maquette ne replie pas ses rangées sur des seuils de fenêtre : chaque colonne
			 * porte `flex: 1 1 340px` et la rangée se replie quand la place manque. Le seuil réel
			 * varie donc de 600 à 900 px d'une bande à l'autre, et aucune valeur globale ne les
			 * reproduit toutes. À 768 px, la maquette donnait 707 px de large à ses bandes de
			 * texte quand le thème en donnait 333.
			 */
			/*
			 * Base de colonne : la MOYENNE des bases déclarées par les colonnes de la rangée, et non
			 * celle de la première.
			 *
			 * Le prototype compose ses rangées en flex : chaque colonne porte sa propre base, et la
			 * rangée se replie quand la SOMME des bases plus les écarts dépasse la place disponible.
			 * Le thème la rend en grille `auto-fit`, qui se replie quand N × base plus les écarts la
			 * dépasse. Les deux points de bascule coïncident exactement quand la base de la grille
			 * vaut la moyenne des bases du flex — et seulement alors.
			 *
			 * Sur la bande « Ce que nous attendons » de /recrutement/, les deux colonnes déclarent
			 * 340 et 320 px. Prendre 340 faisait replier la rangée à 768 px (2 × 340 + 30,72 = 710,7
			 * pour 707 disponibles) là où la maquette la tient côte à côte ; la moyenne, 330, la tient
			 * (2 × 330 + 30,72 = 690,7). La largeur des colonnes reste égalisée par la grille — 338
			 * contre 348 et 328 dans la maquette — ce que seule une rangée flex à bases distinctes
			 * reproduirait au pixel.
			 */
			$bases = array();
			foreach ( $sequence as $bloc_rangee ) {
				$base = tfp_longueur_css( $bloc_rangee['colonne_min'] ?? '' );
				if ( '' !== $base && preg_match( '/^([\d.]+)px$/', $base, $m ) ) {
					$bases[] = (float) $m[1];
				}
			}
			$rangee_vars = array();
			if ( $bases ) {
				$rangee_vars[] = '--tfp-rangee-colonne:' . round( array_sum( $bases ) / count( $bases ), 2 ) . 'px';
			} elseif ( '' !== tfp_longueur_css( $sequence[0]['colonne_min'] ?? '' ) ) {
				$rangee_vars[] = '--tfp-rangee-colonne:' . tfp_longueur_css( $sequence[0]['colonne_min'] );
			}
			if ( '' !== tfp_longueur_css( $sequence[0]['rangee_gap'] ?? '' ) ) {
				$rangee_vars[] = '--tfp-rangee-gap:' . tfp_longueur_css( $sequence[0]['rangee_gap'] );
			}
			$rangee_style = $en_grille && $rangee_vars ? ' style="' . esc_attr( implode( ';', $rangee_vars ) ) . '"' : '';
			?>
			<div class="<?php echo $en_grille ? esc_attr( 'tfp-static-grid tfp-static-grid--' . (int) $colonnes_rangee ) : 'tfp-static-run'; ?>"<?php echo $rangee_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
			<?php
			foreach ( $sequence as $bloc ) :
				// Les clés absentes d'un bloc généré avant l'ajout d'un type de contenu ne doivent pas
				// faire tomber le rendu : on complète systématiquement.
				$bloc = wp_parse_args(
					$bloc,
					array( 'titre' => '', 'niveau' => 'h2', 'textes' => array(), 'liste' => array(), 'liens' => array(), 'noms' => array(), 'citations' => array(), 'faq' => array(), 'etapes' => array() )
				);
				// Un bloc qui porte des citations est un bloc de témoignages repris de la maquette : il
				// est marqué provisoire, comme les cartes témoignage, pour rester repérable en une
				// requête et pour être exclu du contrôle « aucune donnée fictive » — il est destiné à
				// être remplacé par de vrais avis (CLAUDE.md §5.5).
				$provisoire = ! empty( $bloc['citations'] );
				?>
					<?php
					/*
					 * L'encadrement se lit **sur le bloc**, pas sur la bande.
					 *
					 * La maquette encadre couramment un seul bloc au milieu d'une bande de texte
					 * suivi. Une décision prise à la majorité pour toute la bande ne sait pas
					 * l'exprimer : elle encadrait tout, ou rien. Elle encadrait notamment des
					 * bandes dont le contenu est déjà une grille de cartes — une carte dans une
					 * carte, absente de la référence, qui retirait 38 px de largeur utile et
					 * faisait replier chaque description sur une ligne de plus.
					 *
					 * La valeur de bande ne sert plus que de repli, pour un contenu produit avant
					 * l'introduction du relevé par bloc.
					 */
					$carte_bloc  = array_key_exists( 'carte', $bloc ) ? ( is_array( $bloc['carte'] ) ? $bloc['carte'] : null ) : $carte;
					$carte_style = $carte_style_de( $carte_bloc );
					?>
					<div class="tfp-static-block<?php echo $carte_bloc ? ' tfp-static-block--carte' : ''; ?><?php echo $carte_sombre( $carte_bloc ) ? ' tfp-static-block--carte-sombre' : ''; ?>"<?php echo $carte_style ? ' style="' . esc_attr( $carte_style ) . '"' : ''; ?><?php echo $provisoire ? ' data-tfp-provisional="1"' : ''; ?>>
						<?php
						// Le visiteur ne lit pas le code source : un attribut ne l'informe de rien. La
						// mention est donc visible, dans le flux, au plus près du contenu concerné.
						if ( $provisoire ) {
							tfp_provisional_notice();
						}
						?>
						<?php
						/*
						 * Typographie de l'intertitre, relevée bloc par bloc (G26 §5).
						 *
						 * La maquette compose ses intertitres de 17 à 40 px selon la bande ; le thème
						 * appliquait ses deux jetons partout, et 70 des 108 intertitres appariés des
						 * neuf pages statiques sortaient à la mauvaise taille. La taille relevée est
						 * la FONCTION déclarée par le prototype, pas sa valeur à 1440 px, et
						 * l'interligne est un ratio : l'un comme l'autre suivent la largeur de la
						 * fenêtre au lieu d'y être figés. Sans relevé, les jetons du thème
						 * s'appliquent — c'est-à-dire le comportement d'avant.
						 */
						// Section repliée : son titre est déjà dans le résumé du volet, il n'est pas répété.
						if ( $est_repliee && ! $titre_saute && trim( (string) ( $bloc['titre'] ?? '' ) ) === $titre_repli ) {
							$titre_saute = true;
						} else {
							tfp_bloc_titre( $bloc );
						}
						?>

						<?php
						/*
						 * Rendu de la **séquence hétérogène ordonnée** de la bande.
						 *
						 * Le composant rendait auparavant un tiroir après l'autre — tous les paragraphes,
						 * puis toutes les listes, puis toutes les pastilles — ce qui effaçait l'ordre
						 * voulu par la maquette : une note écrite entre deux grilles ressortait après
						 * elles. La séquence porte chaque enfant avec son type, dans son ordre de
						 * lecture, et chacun garde l'archétype que le prototype lui donne.
						 *
						 * Il n'y a **plus de repli** vers la pastille : un fragment n'est rendu en chip
						 * que si la maquette le rend en chip, ce qui est relevé à l'extraction.
						 */
						$sequence_bloc = is_array( $bloc['sequence'] ?? null ) ? $bloc['sequence'] : array();
						if ( ! $sequence_bloc ) {
							// Repli de compatibilité pour un contenu produit avant l'introduction de la
							// séquence : on reconstitue l'ordre le plus probable, sans jamais inventer de
							// pastille.
							foreach ( $bloc['textes'] as $t ) {
								$sequence_bloc[] = array( 'type' => 'paragraph', 'texte' => $t );
							}
							foreach ( $bloc['cartes'] as $g ) {
								$sequence_bloc[] = array_merge( array( 'type' => 'grid' ), $g );
							}
							if ( ! empty( $bloc['liste'] ) ) {
								$sequence_bloc[] = array( 'type' => 'list', 'items' => $bloc['liste'] );
							}
						}

						$chips_en_attente = array();
						/*
						 * RANGÉES DE COMMANDES — G26 §4 et §5.
						 *
						 * La maquette pose ses appels à l'action en rangées de boutons côte à côte ; le
						 * composant les rendait en lignes de texte pleine largeur empilées. Sur
						 * /a-propos/ cela transformait six commandes en une liste, sur /recrutement/
						 * cela remplaçait le parcours de candidature par des liens génériques.
						 *
						 * Les liens consécutifs qui partagent la rangée relevée sont donc regroupés et
						 * rendus avec l'archétype mesuré sur le prototype. Un lien sans rangée ni
						 * archétype relevé garde sa ligne de texte : rien n'est promu bouton sans relevé.
						 */
						/*
						 * Sur une bande sombre, la hiérarchie s'inverse — le principal passe en blanc
						 * plein, le secondaire en filet blanc translucide. Le design system porte déjà
						 * ces deux variantes (`--on-primary`, `--on-dark`) ; on les choisit ici plutôt
						 * que d'écrire une règle contextuelle qui les dupliquerait. Sans cela, un
						 * bouton bleu sur bande marine devient illisible : c'est un défaut de
						 * contraste avant d'être un défaut de fidélité (CLAUDE.md §8).
						 */
						$bande_sombre     = in_array( $section['fond'] ?? '', array( 'primary', 'navy' ), true );
						/*
						 * File des étapes numérotées consécutives : la maquette les empile dans un
						 * même conteneur, et elles forment sémantiquement une liste ordonnée — ce
						 * qu'une suite de paragraphes ne dit ni à l'œil ni à un lecteur d'écran.
						 */
						$etapes_en_attente = array();
						$vider_etapes      = static function () use ( &$etapes_en_attente ) {
							if ( ! $etapes_en_attente ) {
								return;
							}
							$etapes            = $etapes_en_attente;
							$etapes_en_attente = array();
							echo '<ol class="tfp-step-lines">';
							foreach ( $etapes as $e ) {
								printf(
									'<li class="tfp-step-line"><span class="tfp-step-line__num" aria-hidden="true">%s</span><span class="tfp-step-line__txt">%s</span></li>',
									esc_html( $e['numero'] ),
									esc_html( $e['texte'] )
								);
							}
							echo '</ol>';
						};
						$liens_en_attente = array();
						$vider_liens      = static function () use ( &$liens_en_attente, $bande_sombre ) {
							if ( ! $liens_en_attente ) {
								return;
							}
							$liens            = $liens_en_attente;
							$liens_en_attente = array();
							echo '<div class="tfp-action-row tfp-action-row--statique">';
							foreach ( $liens as $l ) {
								$principal = 'primaire' === $l['archetype'];
								if ( $bande_sombre ) {
									$variante = $principal ? 'on-primary' : 'on-dark';
								} else {
									$variante = $principal ? 'primary' : 'secondary';
								}
								if ( 0 === strpos( (string) $l['href'], 'tel:' ) ) {
									// Appel relevé (« ☎ 06 36 17 63 39 », « ☎ Échanger avec Audrey ») :
									// composant d'appel unique, numéro affiché si la maquette l'affichait.
									tfp_bouton_appel(
										array(
											'variant' => $variante,
											'numero'  => (bool) preg_match( '/\d{2}[\s.]?\d{2}/', (string) $l['label'] ),
											'mesures' => $l['mesures'],
										)
									);
									continue;
								}
								tfp_button(
									array(
										'label'   => $l['label'],
										'href'    => $l['href'],
										'variant' => $variante,
										'mesures' => $l['mesures'],
									)
								);
							}
							echo '</div>';
						};
						/** Vide la file de pastilles consécutives en une seule rangée, comme la maquette. */
						$vider_chips = static function () use ( &$chips_en_attente ) {
							if ( ! $chips_en_attente ) {
								return;
							}
							tfp_chip_list(
								array_map(
									static function ( $t ) {
										return array( 'texte' => $t );
									},
									$chips_en_attente
								)
							);
							$chips_en_attente = array();
						};

						$rangee_courante = null;
						/*
						 * Bandeau tarifaire relevé (pilier, région, prestations, tarifs) : la maquette
						 * compose pastille, garanties et bouton dans une seule rangée ; le relevé en
						 * fait un panneau à une colonne de deux « cartes » suivi d'un paragraphe qui
						 * concatène les trois garanties. Rendu générique, cela donnait deux barres
						 * marine pleine largeur et un texte nu sans coche (revue du 21 octobre). Le
						 * panneau est reconnu à sa forme et rendu par le composant partagé ; le
						 * paragraphe des garanties qui le suit est consommé, puisque le composant les
						 * porte déjà.
						 */
						$garanties_a_consommer = false;
						$est_bande_tarif       = static function ( array $g ) {
							$items = (array) ( $g['items'] ?? array() );
							if ( empty( $g['panneau_fond'] ) || 2 !== count( $items ) ) {
								return false;
							}
							return (bool) preg_match( '/^\d+(?:[,.]\d+)?\s*€\s*HT\/h$/u', trim( (string) ( $items[0]['titre'] ?? '' ) ) )
								&& ! empty( $items[1]['route'] );
						};
						foreach ( $sequence_bloc as $enfant ) {
							$type = $enfant['type'] ?? '';
							if ( $garanties_a_consommer ) {
								$garanties_a_consommer = false;
								$attendu = preg_replace( '/\s+/u', ' ', implode( ' ', tfp_band_items() ) );
								$recu    = preg_replace( '/\s+/u', ' ', trim( (string) ( $enfant['texte'] ?? '' ) ) );
								// Relevé tantôt en paragraphe, tantôt en note : la forme varie, le texte non.
								if ( in_array( $type, array( 'paragraph', 'note' ), true ) && $attendu === $recu ) {
									continue;
								}
							}
							if ( 'chip' !== $type ) {
								$vider_chips();
							}
							if ( 'step-ligne' !== $type ) {
								$vider_etapes();
							}
							// La rangée se referme dès qu'un contenu d'un autre type s'intercale, ou dès
							// qu'un lien appartient à une autre rangée relevée.
							if ( 'link' !== $type || ( $enfant['rangee'] ?? '' ) !== $rangee_courante ) {
								$vider_liens();
								$rangee_courante = 'link' === $type ? ( $enfant['rangee'] ?? '' ) : null;
							}
							switch ( $type ) {
								case 'paragraph':
									/*
									 * Un paragraphe relevé en graisse 600 et court est un INTERTITRE de la
									 * maquette (« Suivi & interlocuteur dédié », 17 px / 600), pas une ligne de
									 * texte courant. Rendu en gris 17 px régulier, il se confondait avec le
									 * paragraphe qu'il annonce (page pilier, revue du 21 octobre).
									 */
									$graisse  = (int) ( $enfant['graisse'] ?? 400 );
									$intertitre = $graisse >= 600 && mb_strlen( (string) $enfant['texte'] ) <= 90;
									printf( '<p class="tfp-prose%s">%s</p>', $intertitre ? ' tfp-prose--intertitre' : '', esc_html( tfp_montants_insecables( $enfant['texte'] ) ) );
									break;

								case 'step-ligne':
									$etapes_en_attente[] = array(
										'numero' => (string) ( $enfant['numero'] ?? '' ),
										'texte'  => (string) ( $enfant['texte'] ?? '' ),
									);
									break;

								case 'note':
									// Phrase de transition, précision, conclusion : du texte courant, et
									// non une pastille. C'est exactement ce que produisait le repli
									// supprimé, et cela inventait des cartes absentes du prototype.
									// Une note relevée en graisse 600 et courte est un INTERTITRE de la maquette
									// (« Suivi & interlocuteur dédié ») : rendue en note grise, elle se
									// confondait avec le paragraphe qu'elle annonce (page pilier, revue du
									// 21 octobre).
									$intertitre = (int) ( $enfant['graisse'] ?? 400 ) >= 600 && mb_strlen( (string) $enfant['texte'] ) <= 90;
									printf( '<p class="%s">%s</p>', $intertitre ? 'tfp-prose tfp-prose--intertitre' : 'tfp-static-note', esc_html( $enfant['texte'] ) );
									break;

								case 'grid':
									if ( $est_bande_tarif( $enfant ) ) {
										$items = $enfant['items'];
										tfp_bande_tarif(
											array(
												'prix'       => trim( (string) $items[0]['titre'] ),
												'note'       => trim( (string) ( $items[0]['description'] ?? '' ) ),
												'lien_label' => trim( (string) ( $items[1]['titre'] ?? 'Voir les tarifs →' ) ),
												'lien_url'   => tfp_route_to_url( (string) $items[1]['route'] ),
												'classe'     => 'tfp-price-band--statique',
											)
										);
										$garanties_a_consommer = true;
										break;
									}
									tfp_card_grid( $enfant );
									break;

								case 'list':
									echo '<ul class="tfp-list-plain">';
									foreach ( (array) ( $enfant['items'] ?? array() ) as $item ) {
										printf( '<li>%s</li>', esc_html( $item ) );
									}
									echo '</ul>';
									break;

								case 'quote':
									printf( '<blockquote class="tfp-quote">%s</blockquote>', esc_html( $enfant['texte'] ) );
									break;

								case 'link':
									$route = (string) ( $enfant['route'] ?? '' );
									/*
									 * Un `tel:` ou un `mailto:` relevé sur la maquette est réécrit avec
									 * les coordonnées RÉELLES du site (PROJECT_INPUTS.md §1), jamais
									 * avec celles figées dans le prototype : le numéro y est certes le
									 * bon aujourd'hui, mais le jour où il change, une valeur recopiée
									 * dans une option de contenu ne suivrait pas.
									 */
									$contact = function_exists( 'tfp_site_data' ) ? tfp_site_data() : array();
									/*
									 * Redirection de lien DÉCLARÉE par le gabarit appelant (G26 §5).
									 *
									 * /recrutement/ s'en sert pour envoyer « Envoyer ma candidature »
									 * vers le site carrière plutôt que vers le `mailto:` du prototype,
									 * comme CLAUDE.md §8 l'impose. La substitution est écrite dans le
									 * gabarit de la page, en clair, plutôt que devinée ici d'après un
									 * libellé : une règle implicite se serait appliquée un jour à une
									 * page qui ne l'attendait pas.
									 */
									if ( isset( $liens_rediriges[ $route ] ) ) {
										$url = $liens_rediriges[ $route ];
									} elseif ( 0 === strpos( $route, 'tel:' ) ) {
										$url = 'tel:' . ( $contact['phone_href'] ?? '' );
									} elseif ( 0 === strpos( $route, 'mailto:' ) ) {
										$url = 'mailto:' . ( $contact['email'] ?? '' );
									} else {
										$url = tfp_route_to_url( $route );
									}

									$archetype = (string) ( $enfant['archetype'] ?? 'ligne' );
									/*
									 * Décision du 14 octobre 2026 : l'appel téléphonique se nomme « Appeler
									 * Top-Famille Pro » sur tout le site. La maquette écrit encore « ☎ Appeler
									 * Audrey » sur /avis-clients/ ; le libellé est aligné ici, à la source,
									 * sans toucher aux autres formulations relevées (« ☎ 06 36 17 63 39 »).
									 */
									$libelle_lien = (string) $enfant['texte'];
									if ( 0 === strpos( $route, 'tel:' ) && preg_match( '/Appeler Audrey/u', $libelle_lien ) && function_exists( 'tfp_phone_cta_label' ) ) {
										$libelle_lien = tfp_phone_cta_label();
									}
									/*
									 * Carte-lien à fond plein (passe visuelle du 14 octobre 2026).
									 *
									 * La carte « Bourgogne-Franche-Comté » de /zones-intervention/ était
									 * relevée comme une « ligne » et rendue comme telle : ses trois
									 * textes se retrouvaient collés en une seule phrase de 138 px sans
									 * espace. Le générateur relève désormais le titre, la sous-ligne et
									 * le pseudo-bouton séparément ; la carte est recomposée ici, avec
									 * la géométrie de la maquette (fond primaire, rayon 18, pastille
									 * blanche). Tout est en `<span>` : un `<a>` reste un contenu
									 * phrasé valide, et aucun bouton n'est imbriqué dans un lien.
									 */
									if ( $url && 'carte' === $archetype && ! empty( $enfant['carte']['titre'] ) ) {
										$carte = (array) $enfant['carte'];
										$desc  = trim( (string) ( $carte['description'] ?? '' ) );
										printf(
											'<a class="tfp-carte-lien" href="%s"><span class="tfp-carte-lien__corps"><span class="tfp-carte-lien__titre">%s</span>%s</span>'
												. '<span class="tfp-carte-lien__cta">%s<span aria-hidden="true"> →</span></span></a>',
											esc_url( $url ),
											esc_html( $carte['titre'] ),
											'' !== $desc ? '<span class="tfp-carte-lien__desc">' . esc_html( $desc ) . '</span>' : '',
											esc_html( rtrim( (string) ( $carte['cta'] ?? '' ), '→ ' ) )
										);
										break;
									}
									if ( $url && 'ligne' !== $archetype ) {
										// Bouton relevé : il rejoint sa rangée, vidée par le tour suivant.
										$liens_en_attente[] = array(
											// Libellé conservé tel quel, flèche comprise : la maquette écrit
										// « Pourquoi nous choisir → » dans la pastille, et « Page
										// contact » sans flèche. La distinction est la sienne.
										'label'     => $libelle_lien,
											'href'      => $url,
											'archetype' => $archetype,
											'mesures'   => array(
												'pad_v'   => $enfant['pad_v'] ?? '',
												'pad_h'   => $enfant['pad_h'] ?? '',
												'taille'  => $enfant['taille'] ?? '',
												'graisse' => $enfant['graisse'] ?? 0,
												'hauteur' => $enfant['hauteur'] ?? '',
											),
										);
										break;
									}

									if ( $url ) {
										printf(
											'<a class="tfp-link-row" href="%s">%s<span aria-hidden="true">→</span></a>',
											esc_url( $url ),
											esc_html( rtrim( $libelle_lien, '→ ' ) )
										);
									} else {
										// Aucun lien mort publié : le libellé reste du texte (CLAUDE.md §8).
										printf( '<span class="tfp-link-row tfp-link-row--static">%s</span>', esc_html( $enfant['texte'] ) );
									}
									break;

								case 'chip':
									$chips_en_attente[] = $enfant['texte'];
									break;

								case 'step':
									printf(
										'<ol class="tfp-steps"><li class="tfp-step"><span class="tfp-step__num" aria-hidden="true">%s</span>'
											. '<div class="tfp-step__body"><strong class="tfp-step__titre">%s</strong><p class="tfp-prose">%s</p></div></li></ol>',
										esc_html( $enfant['numero'] ),
										esc_html( $enfant['titre'] ),
										esc_html( $enfant['texte'] )
									);
									break;

								case 'faq':
									printf(
										'<details class="tfp-card tfp-faq-item"><summary>%s</summary><p>%s</p></details>',
										esc_html( $enfant['question'] ),
										esc_html( $enfant['reponse'] )
									);
									break;
							}
						}
						$vider_chips();
						$vider_etapes();
						$vider_liens();
						?>
					</div>
			<?php endforeach; ?>
			</div>
		<?php endforeach; ?>
		<?php if ( $est_repliee ) : ?>
			</div></details>
		<?php endif; ?>
		</div>
	</section>
	<?php
}

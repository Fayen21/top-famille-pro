<?php
/**
 * Traitement serveur du formulaire de demande de devis (/demande-de-devis/, CLAUDE.md §8).
 *
 * Volontairement sans dépendance ACF ni plugin de formulaire : `admin-post.php`, le mécanisme
 * natif de WordPress pour traiter un POST public sans REST API ni JavaScript côté serveur.
 * Fonctionne sans configuration SMTP dédiée (wp_mail() utilise le transport mail() de PHP par
 * défaut) — un vrai envoi, pas une simulation, même si l'adresse d'expédition/relais définitive
 * (PROJECT_INPUTS.md, question ouverte #4) reste à confirmer côté hébergement en phase 4.
 *
 * Validation client (src/js/quote-form.js) ET serveur (ici) — CLAUDE.md §8 : le client peut être
 * contourné, seule la validation serveur est une garantie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Types de locaux proposés à l'étape 1 et prestation correspondante.
 *
 * Une seule table pour le gabarit (liste et préremplissage) et pour le traitement serveur : le
 * libellé de la prestation reçue par e-mail se DÉDUIT du type de locaux choisi en dernier, il ne
 * se recopie plus depuis la page d'origine. Recette du 12 novembre 2026 : arrivé depuis Bureaux, un
 * prospect qui choisissait « Commerces » envoyait une demande marquée « Nettoyage de bureaux ».
 * Les intitulés de prestation sont ceux que transmettent les pages prestation (`service_label`).
 *
 * @return array<string, array{label: string, prestation: string}>
 */
function tfp_quote_types_locaux() {
	return array(
		'bureaux'      => array( 'label' => 'Bureaux', 'prestation' => 'Nettoyage de bureaux' ),
		'commerces'    => array( 'label' => 'Commerces', 'prestation' => 'Nettoyage de commerces' ),
		'cabinets'     => array( 'label' => 'Cabinets & professions libérales', 'prestation' => 'Nettoyage de cabinets' ),
		'coproprietes' => array( 'label' => 'Copropriété / parties communes', 'prestation' => 'Entretien de copropriétés' ),
		'meubles'      => array( 'label' => 'Location meublée / hébergement', 'prestation' => 'Nettoyage de locations meublées' ),
		'ponctuel'     => array( 'label' => 'Remise en état ponctuelle', 'prestation' => 'Nettoyage ponctuel' ),
		'autre'        => array( 'label' => 'Autre', 'prestation' => 'Autre besoin' ),
	);
}

/**
 * Prestation demandée, déduite des choix de l'étape 1 : type de locaux et régime.
 *
 * Le régime est toujours précisé, sauf quand il répète le type (« Nettoyage ponctuel » en
 * intervention ponctuelle). Un type inconnu ne produit rien : la demande n'invente pas de
 * prestation. Même règle que src/js/quote-form.js (`prestationDemandee`).
 *
 * @param string $type   Clé de tfp_quote_types_locaux().
 * @param string $regime « regulier » ou « ponctuel ».
 * @return string
 */
function tfp_quote_prestation_demandee( $type, $regime ) {
	$types = tfp_quote_types_locaux();
	if ( ! isset( $types[ $type ] ) ) {
		return '';
	}
	$libelle  = $types[ $type ]['prestation'];
	$regimes  = array( 'regulier' => 'entretien régulier', 'ponctuel' => 'intervention ponctuelle' );
	if ( isset( $regimes[ $regime ] ) && ! ( 'ponctuel' === $type && 'ponctuel' === $regime ) ) {
		$libelle .= ' (' . $regimes[ $regime ] . ')';
	}
	return $libelle;
}

/**
 * Limite de soumissions : 5 par heure et par IP, via un transitoire (pas de table dédiée).
 *
 * @param string $ip
 * @return bool true si la soumission est autorisée.
 */
function tfp_quote_rate_limit_ok( $ip ) {
	$key   = 'tfp_devis_' . md5( $ip );
	$count = (int) get_transient( $key );
	if ( $count >= 5 ) {
		return false;
	}
	set_transient( $key, $count + 1, HOUR_IN_SECONDS );
	return true;
}

/**
 * L'envoi d'e-mail est-il neutralisé sur cette installation ?
 *
 * Même garde-fou que `tfp_contact_mail_disabled()`, et pour la même raison : aucun test ne doit
 * faire partir un e-mail réel. Le formulaire de devis en était dépourvu — il ne devait sa
 * sûreté qu'à l'ABSENCE de transport mail sur le banc, ce qui n'est pas une garantie mais une
 * circonstance. Sur une préproduction Hostinger, qui a un transport, la suite fonctionnelle
 * aurait expédié six demandes de devis à la gérante à chaque exécution.
 *
 * @return bool
 */
function tfp_quote_mail_disabled() {
	return in_array( wp_get_environment_type(), array( 'local', 'development' ), true );
}

function tfp_handle_quote_submission() {
	$redirect_base = home_url( '/demande-de-devis/' );

	if ( ! isset( $_POST['tfp_quote_nonce'] ) || ! wp_verify_nonce( $_POST['tfp_quote_nonce'], 'tfp_quote_submit' ) ) {
		wp_safe_redirect( add_query_arg( 'erreur', 'session', $redirect_base ) );
		exit;
	}

	// Honeypot : champ caché aux visiteurs humains, souvent rempli par les robots. Rejet
	// silencieux (pas d'indice donné au robot que le champ a été détecté).
	if ( ! empty( $_POST['tfp_site_web'] ) ) {
		wp_safe_redirect( $redirect_base );
		exit;
	}

	$nom        = isset( $_POST['nom'] ) ? sanitize_text_field( wp_unslash( $_POST['nom'] ) ) : '';
	$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$telephone  = isset( $_POST['telephone'] ) ? sanitize_text_field( wp_unslash( $_POST['telephone'] ) ) : '';
	$entreprise = isset( $_POST['entreprise'] ) ? sanitize_text_field( wp_unslash( $_POST['entreprise'] ) ) : '';
	$message    = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	$consentement = ! empty( $_POST['consentement'] );

	$type_locaux = isset( $_POST['type_locaux'] ) ? sanitize_text_field( wp_unslash( $_POST['type_locaux'] ) ) : '';
	$regime      = isset( $_POST['regime'] ) ? sanitize_text_field( wp_unslash( $_POST['regime'] ) ) : '';
	$code_postal = isset( $_POST['code_postal'] ) ? sanitize_text_field( wp_unslash( $_POST['code_postal'] ) ) : '';
	$surface     = isset( $_POST['surface'] ) ? sanitize_text_field( wp_unslash( $_POST['surface'] ) ) : '';
	$frequence   = isset( $_POST['frequence'] ) ? sanitize_text_field( wp_unslash( $_POST['frequence'] ) ) : '';
	$creneau     = isset( $_POST['creneau'] ) ? sanitize_text_field( wp_unslash( $_POST['creneau'] ) ) : '';

	/*
	 * Prestation demandée : recalculée ICI depuis le type de locaux et le régime reçus, qui sont les
	 * derniers choix du prospect. Le champ caché `prestation` n'est plus qu'un repli (type inconnu,
	 * formulaire ancien resté en cache). La prestation de la page d'origine est une information
	 * distincte, transmise à part et rangée dans le contexte de la demande.
	 */
	$prestation = tfp_quote_prestation_demandee( $type_locaux, $regime );
	if ( '' === $prestation && isset( $_POST['prestation'] ) ) {
		$prestation = sanitize_text_field( wp_unslash( $_POST['prestation'] ) );
	}
	$prestation_origine = isset( $_POST['prestation_origine'] ) ? sanitize_text_field( wp_unslash( $_POST['prestation_origine'] ) ) : '';
	$ville       = isset( $_POST['ville'] ) ? sanitize_text_field( wp_unslash( $_POST['ville'] ) ) : '';
	$departement = isset( $_POST['departement'] ) ? sanitize_text_field( wp_unslash( $_POST['departement'] ) ) : '';
	$page_origine = isset( $_POST['page_origine'] ) ? esc_url_raw( wp_unslash( $_POST['page_origine'] ) ) : '';
	$referent    = isset( $_POST['referent'] ) ? sanitize_text_field( wp_unslash( $_POST['referent'] ) ) : '';
	$utm_source   = isset( $_POST['utm_source'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_source'] ) ) : '';
	$utm_medium   = isset( $_POST['utm_medium'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_medium'] ) ) : '';
	$utm_campaign = isset( $_POST['utm_campaign'] ) ? sanitize_text_field( wp_unslash( $_POST['utm_campaign'] ) ) : '';

	// Un moyen de recontacter est requis (téléphone OU e-mail, pas nécessairement les deux), mais si
	// un e-mail est fourni il doit être valide. Validation des champs avant la limitation de
	// fréquence : une requête mal formée ne doit pas pouvoir consommer le quota d'un visiteur
	// légitime partageant la même adresse IP.
	$email_fourni_invalide = ( '' !== $email ) && ! is_email( $email );
	$aucun_contact         = empty( $telephone ) && empty( $email );
	// Code postal : vide, ou exactement cinq chiffres (même règle que le client, revue du 25 octobre 2026).
	$code_postal_invalide = ( '' !== $code_postal ) && ! preg_match( '/^[0-9]{5}$/', $code_postal );
	if ( empty( $nom ) || $aucun_contact || $email_fourni_invalide || $code_postal_invalide || empty( $message ) || ! $consentement ) {
		wp_safe_redirect( add_query_arg( 'erreur', 'champs', $redirect_base ) );
		exit;
	}

	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( ! tfp_quote_rate_limit_ok( $ip ) ) {
		wp_safe_redirect( add_query_arg( 'erreur', 'limite', $redirect_base ) );
		exit;
	}

	$site = tfp_site_data();

	$type_locaux_labels = wp_list_pluck( tfp_quote_types_locaux(), 'label' );
	$regime_labels      = array( 'regulier' => 'Régulier', 'ponctuel' => 'Ponctuel' );
	$frequence_labels   = array( 'quotidien' => 'Quotidien', 'plusieurs-semaine' => 'Plusieurs fois par semaine', 'hebdomadaire' => 'Hebdomadaire', 'bimensuel' => 'Toutes les deux semaines', 'mensuel' => 'Mensuel', 'ponctuel' => 'Une seule fois' );
	$creneau_labels     = array( 'matin' => "Tôt le matin, avant l'arrivée des équipes", 'soir' => 'En soirée, après le départ des équipes', 'journee' => 'En journée', 'weekend' => 'Le week-end' );

	$lines   = array();
	$lines[] = 'Nom : ' . $nom;
	if ( $email ) { $lines[] = 'E-mail : ' . $email; }
	if ( $telephone ) { $lines[] = 'Téléphone : ' . $telephone; }
	if ( $entreprise ) { $lines[] = 'Entreprise : ' . $entreprise; }
	if ( $type_locaux ) { $lines[] = 'Type de locaux : ' . ( isset( $type_locaux_labels[ $type_locaux ] ) ? $type_locaux_labels[ $type_locaux ] : $type_locaux ); }
	if ( $regime ) { $lines[] = 'Régime : ' . ( isset( $regime_labels[ $regime ] ) ? $regime_labels[ $regime ] : $regime ); }
	if ( $ville ) { $lines[] = 'Ville : ' . $ville; }
	if ( $code_postal ) { $lines[] = 'Code postal : ' . $code_postal; }
	if ( $surface ) { $lines[] = 'Surface approximative : ' . $surface; }
	if ( $departement ) { $lines[] = 'Département : ' . $departement; }
	if ( $prestation ) { $lines[] = 'Prestation demandée : ' . $prestation; }
	if ( $frequence ) { $lines[] = 'Fréquence souhaitée : ' . ( isset( $frequence_labels[ $frequence ] ) ? $frequence_labels[ $frequence ] : $frequence ); }
	if ( $creneau ) { $lines[] = 'Créneau souhaité : ' . ( isset( $creneau_labels[ $creneau ] ) ? $creneau_labels[ $creneau ] : $creneau ); }
	$lines[] = '';
	$lines[] = 'Message :';
	$lines[] = $message;
	$lines[] = '';
	$lines[] = '--- Contexte de la demande ---';
	if ( $page_origine ) { $lines[] = 'Page d\'origine : ' . $page_origine; }
	if ( $prestation_origine ) { $lines[] = 'Prestation de la page d\'origine : ' . $prestation_origine; }
	if ( $referent ) { $lines[] = 'Référent : ' . $referent; }
	if ( $utm_source || $utm_medium || $utm_campaign ) {
		$lines[] = sprintf( 'UTM : source=%s medium=%s campaign=%s', $utm_source, $utm_medium, $utm_campaign );
	}
	$lines[] = 'IP : ' . $ip;

	$body    = implode( "\n", $lines );
	$subject = sprintf( '[Demande de devis] %s', $nom );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
	if ( $email ) {
		$headers[] = 'Reply-To: ' . $nom . ' <' . $email . '>';
	}

	// Sur une installation de test, la demande est validée de bout en bout mais jamais expédiée.
	$sent = tfp_quote_mail_disabled() ? true : wp_mail( $site['email'], $subject, $body, $headers );

	if ( ! $sent ) {
		wp_safe_redirect( add_query_arg( 'erreur', 'envoi', $redirect_base ) );
		exit;
	}

	wp_safe_redirect( add_query_arg( 'merci', '1', $redirect_base ) );
	exit;
}
add_action( 'admin_post_nopriv_tfp_submit_devis', 'tfp_handle_quote_submission' );
add_action( 'admin_post_tfp_submit_devis', 'tfp_handle_quote_submission' );

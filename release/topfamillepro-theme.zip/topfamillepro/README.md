# Top-Famille Pro — thème enfant WordPress

Thème enfant sur mesure pour **Top-Famille Pro** (SARL TOP-ENTREPRISE), basé sur le thème parent
**GeneratePress**.

## Installation

1. Installer et activer le thème parent **GeneratePress** (gratuit, WordPress.org) — WordPress
   refuse d'activer un thème enfant dont le parent est absent.
2. Téléverser ce thème depuis l'administration WordPress :
   *Apparence → Thèmes → Ajouter un thème → Téléverser un thème* → sélectionner le fichier
   `topfamillepro-theme.zip` fourni (pas ce dossier extrait) → *Installer maintenant* → *Activer*.
3. Installer et activer **ACF** (Advanced Custom Fields), version gratuite suffisante — aucun
   champ Repeater/Flexible Content/Gallery/Clone ni page d'options ACF n'est utilisé (ces
   fonctionnalités sont exclusives à ACF PRO). Sans ACF (absent ou inactif), le thème ne plante
   pas : les types de contenu restent enregistrés, seuls leurs champs personnalisés sont absents.
4. Réglages → Permaliens : choisir une structure autre que « Simple » (ex. « Nom de l'article »)
   pour que les URL des prestations et zones d'intervention fonctionnent, puis enregistrer.
5. Installer le contenu réel (53 pages, 6 prestations, 26 zones, 3 articles) via le plugin
   `topfamillepro-content-installer.zip` fourni séparément — voir `GUIDE-DEPLOIEMENT-HOSTINGER.md`.

## Contenu de ce paquet

Ce ZIP contient uniquement les fichiers nécessaires en production : gabarits PHP, logique
partagée (`includes/`), composants (`template-parts/`), et les assets déjà compilés
(`assets/dist/` : CSS/JS minifiés, polices auto-hébergées, images optimisées AVIF/WebP). Aucune
dépendance à Node.js, npm ou aux fichiers sources (`src/`) : ce thème s'exécute tel quel sur
n'importe quel hébergement WordPress standard (PHP ≥ 8.0).

## Support

- Thème parent requis : **GeneratePress**
- PHP ≥ 8.0
- WordPress : structure de permaliens autre que « Simple »
- Plugin recommandé (facultatif) : **ACF** gratuit — le thème fonctionne aussi sans, via un repli
  natif (`get_post_meta()`)

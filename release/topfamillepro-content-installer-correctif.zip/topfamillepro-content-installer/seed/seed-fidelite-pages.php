<?php
/**
 * Contenu des pages statiques narratives, relevé dans la maquette Claude Design.
 *
 * Fichier **généré** par `node tools/generate-pages.mjs` — ne pas éditer à la main.
 *
 * Ces pages sont des pages WordPress classiques (CLAUDE.md §3) : elles n'ont pas de champs
 * ACF. Leur contenu est donc stocké en option, une par page, et rendu par le composant
 * commun template-parts/static-blocks.php. Les routes internes de la maquette (`#/…`) sont
 * conservées telles quelles ici et traduites en URL réelles à l’affichage : rien ne dépend
 * du prototype après installation.
 *
 * Usage : wp eval-file bin/seed-fidelite-pages.php
 */

if ( ! defined( 'WP_CLI' ) && ! defined( 'ABSPATH' ) ) {
	die( "À lancer via WP-CLI : wp eval-file bin/seed-fidelite-pages.php\n" );
}

echo "=== Fidélité Claude Design : pages statiques ===\n";

update_option( 'tfp_page_nettoyage-professionnel', array(
		'h1' => 'Le nettoyage professionnel de vos locaux en Bourgogne-Franche-Comté',
		'lede' => array(
			'Top-Famille Pro organise l\'entretien régulier ou ponctuel des bureaux, commerces, cabinets, copropriétés et locations meublées. Des intervenants sélectionnés, une interlocutrice dédiée et un tarif clair de 27 € HT/h. Pour comprendre ce que recouvre exactement une prestation, lisez notre page nettoyage professionnel.',
		),
		'hero_alt' => 'Intervenant Top-Famille Pro entretenant des bureaux professionnels',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Voir les tarifs →',
								'route' => '#/nos-tarifs',
							),
						),
						'noms' => array(
							'27 € HT/h',
							'tarif unique en région',
							'Devis gratuit sous 24 h',
							'Intervention régulière ou ponctuelle',
							'Conditions d\'arrêt précisées au devis',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le nettoyage professionnel désigne l\'entretien récurrent ou ponctuel de locaux à usage professionnel, réalisé par un prestataire extérieur. Chez Top-Famille Pro, chaque prestation repose sur un cahier des charges défini avec vous, un intervenant sélectionné et un cahier de liaison laissé sur place — au tarif de 27 € HT/h, en régulier comme en ponctuel, avec un devis gratuit sous 24 heures.',
							'Contrairement au ménage à domicile, le nettoyage professionnel s\'organise autour de contraintes propres à l\'entreprise : horaires calés sur l\'activité, accès sécurisé aux locaux, confidentialité des espaces de travail, et un besoin de traçabilité — savoir qui est passé, quand, et pour faire quoi. C\'est cette organisation, plus que le geste de nettoyage lui-même, qui distingue un prestataire structuré d\'une solution improvisée.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => '',
				'colonnes' => 2,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les professionnels que nous accompagnons',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Notre clientèle regroupe des profils très différents, mais partage un même besoin : ne plus avoir à gérer le nettoyage en interne, ni à recruter, encadrer et remplacer un agent d\'entretien salarié.',
						),
						'liste' => array(
							'Dirigeants de PME, sièges sociaux, plateaux tertiaires',
							'Commerçants, boutiques et showrooms',
							'Professions libérales : santé, droit, conseil',
							'Syndics, gestionnaires et bailleurs',
							'Propriétaires de meublés et hébergements',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les types de locaux entretenus',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Chaque type de local a ses propres contraintes : un plateau de bureaux n\'a pas les mêmes priorités qu\'une salle d\'attente médicale ou qu\'un hall d\'immeuble. Nous adaptons le cahier des charges en conséquence, plutôt que d\'appliquer une méthode unique partout.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Bureaux & open-spaces',
							'Surfaces de vente',
							'Cabinets & salles d\'attente',
							'Parties communes',
							'Meublés & hébergements',
							'Sanitaires & cuisines',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => 'blanc',
				'colonnes' => 3,
				'cartes' => array(
					'padding' => '24px',
					'rayon' => '16px',
					'fond' => 'rgb(244, 247, 248)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Prestataire de nettoyage ou recrutement direct ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'C\'est la première question que se posent la plupart des dirigeants que nous rencontrons. Embaucher directement un agent d\'entretien reste possible, et parfois pertinent au-delà d\'un certain volume horaire. Mais cela suppose d\'assumer des tâches que l\'on sous-estime souvent : rédiger l\'offre, trier les candidatures, mener les entretiens, établir le contrat, gérer la paie et les congés, encadrer le travail, prévoir un remplacement en cas d\'arrêt, et racheter le matériel et les produits. Passer par un prestataire consiste à externaliser cette charge administrative et organisationnelle, en échange d\'un tarif horaire plus élevé qu\'un salaire brut.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce que vous n\'avez plus à gérer',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Recrutement, contrat de travail, bulletins de paie, déclarations sociales, congés payés, visites médicales, entretiens annuels. Une seule facture mensuelle remplace l\'ensemble, et le suivi passe par une interlocutrice unique.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce que vous gardez la main sur',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Le périmètre, la fréquence, les horaires et les priorités : tout est écrit dans un cahier des charges que vous validez et pouvez faire évoluer. Vous ne perdez pas le contrôle du travail attendu, vous déléguez son organisation.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce qu\'un prestataire ne remplace pas',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Un prestataire externe n\'est pas présent en continu dans vos locaux et n\'assure pas les gestes du quotidien entre deux passages. Si votre besoin réel est une présence permanente, une embauche directe reste probablement plus adaptée — nous le disons plutôt que de forcer un devis.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 6,
				'fond' => 'navy',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Nos six prestations de nettoyage professionnel',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Nettoyage de bureaux',
							'Open-spaces, salles de réunion, accueil',
							'Nettoyage de commerces',
							'Boutiques, showrooms, surfaces de vente',
							'Cabinets & professions libérales',
							'Santé, droit, conseil, salles d\'attente',
							'Copropriétés & parties communes',
							'Halls, cages d\'escalier, locaux techniques',
							'Locations meublées & hébergements',
							'Meublés, gîtes, hébergements pro',
							'Nettoyage ponctuel & remise en état',
							'Après travaux, grand nettoyage, départ',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 7,
				'fond' => '',
				'colonnes' => 3,
				'cartes' => array(
					'padding' => '22px',
					'rayon' => '14px',
					'fond' => 'rgba(0, 0, 0, 0)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Régulier ou ponctuel, tâches, fréquences et horaires',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Fréquence définie (quotidienne, plusieurs fois par semaine, hebdomadaire), intervenant habituel recherché et cahier de liaison. Frais de gestion de 9 € HT/mois.',
							'Prestation unique et approfondie : remise en état, grand nettoyage, fin de bail. Chiffrée selon le volume et l\'état, sans engagement de suite.',
							'Tôt le matin, en soirée ou en dehors des heures d\'ouverture sur demande, pour ne pas perturber votre activité.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Entretien régulier',
							'Intervention ponctuelle',
							'Horaires adaptés',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Tâches par espace',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(),
						'liste' => array(
							'Postes de travail & mobilier',
							'Sols : aspiration et lavage',
							'Sanitaires & réapprovisionnement',
							'Cuisine / salle de pause',
							'Accueil & vitres intérieures',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Fréquences',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(),
						'liste' => array(
							'Quotidienne (flux importants)',
							'Plusieurs passages / semaine',
							'Hebdomadaire (petites structures)',
							'Ponctuelle, à la demande',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Produits, matériel & clés',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Produits et matériel généralement fournis par le client (modalités précisées au devis). Accès défini avec vous : clés, badge, code ou présence.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Interventions en dehors des horaires d\'ouverture',
						'niveau' => 'h3',
						'grille' => false,
						'textes' => array(
							'Sur demande, nous organisons des interventions tôt le matin, en soirée ou de nuit, ainsi que le dimanche ou les jours fériés lorsque votre activité l\'exige (commerce fermé un jour précis, salle occupée en continu). Ces créneaux font l\'objet d\'une majoration de 10 % du tarif horaire, indiquée à l\'avance sur le devis — jamais découverte après coup.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 8,
				'fond' => 'blanc',
				'colonnes' => 4,
				'cartes' => array(
					'padding' => '22px',
					'rayon' => '14px',
					'fond' => 'rgba(0, 0, 0, 0)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Comment choisir la bonne fréquence',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'La fréquence dépend moins de la surface que du nombre de personnes réellement présentes, du passage extérieur et du nombre de sanitaires. Un plateau de 200 m² occupé par six personnes ne représente pas la même charge que le même plateau occupé par vingt. Trois éléments décident presque toujours : les sanitaires, la salle de pause et les sols de circulation — ce sont eux qui se dégradent en premier et qui déclenchent les remarques internes.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Quotidienne',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Locaux recevant du public en continu, effectif important, restauration sur place, cabinets de groupe. La charge se concentre sur sanitaires, cuisine et circulations ; le reste suit une rotation.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Deux à trois fois par semaine',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Le rythme le plus courant en bureaux : dix à trente postes, une cuisine, deux sanitaires. Il permet d\'alterner les tâches lourdes et de garder un niveau constant sans surcoût inutile.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Hebdomadaire',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Petites structures, cabinets individuels, copropriétés de taille moyenne, bureaux peu occupés ou en télétravail partiel. Un passage plus long permet de tout traiter en une fois.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ponctuelle',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Fin de chantier, fin de bail, remise en état avant ouverture, grand nettoyage saisonnier. Chiffrée en fourchette d\'heures selon l\'état constaté, sans engagement de suite.',
							'Nous préférons démarrer sur une fréquence réaliste puis l\'ajuster après quelques semaines, plutôt que de surdimensionner le devis d\'entrée. Dans les deux sens : il nous arrive de proposer de réduire un volume d\'heures lorsque le cahier de liaison montre que le temps prévu n\'est pas nécessaire.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 9,
				'fond' => '',
				'colonnes' => 3,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les tâches, espace par espace',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Un cahier des charges utile ne liste pas des tâches en vrac : il les répartit par espace et leur associe une fréquence. C\'est ce qui permet à l\'intervenant de savoir quoi faire quand le temps manque, et à vous de savoir ce que vous êtes en droit d\'attendre.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Postes de travail et mobilier',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Dépoussiérage des plans de travail dégagés, du mobilier et des surfaces de contact. Les écrans et claviers font l\'objet d\'un dépoussiérage prudent selon les consignes et le matériel autorisé. Les documents et effets personnels ne sont jamais déplacés : la surface est reprise autour d\'eux.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Sols et circulations',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Aspiration et lavage selon la nature du revêtement : moquette, vinyle, carrelage, parquet, béton ciré, résine. Les circulations et les entrées se salissent trois à quatre fois plus vite que le reste et justifient souvent une fréquence propre, plus élevée que celle des bureaux eux-mêmes.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Sanitaires',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Nettoyage et désinfection des cuvettes, lavabos, robinetteries, miroirs, poignées et sols, avec réapprovisionnement du papier, du savon et des sacs lorsque vous fournissez ces consommables. Tout dysfonctionnement est signalé dans le cahier de liaison plutôt que laissé à la découverte d\'un visiteur.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Cuisine et salle de pause',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Plan de travail, évier, tables, extérieur des appareils, sol et poubelle. L\'intérieur du réfrigérateur, le dégivrage et le nettoyage intérieur du four sont possibles mais planifiés séparément : ils supposent que la cuisine soit vidée et demandent un temps que le passage courant n\'absorbe pas.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Accueil et espaces recevant du public',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Comptoir, assises, tables basses, tapis de propreté, vitrage de la porte d\'entrée, surfaces de contact courantes. C\'est le premier espace vu par un visiteur, et souvent celui sur lequel une négligence se remarque le plus vite : il est traité à chaque passage.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Vitres et surfaces vitrées',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Vitres intérieures, cloisons vitrées, portes et vitrophanies accessibles sans équipement spécialisé, à une fréquence plus espacée. Tout ce qui exige une nacelle, une perche télescopique ou un échafaudage est exclu de la prestation courante et relève d\'un prestataire équipé pour le travail en hauteur.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 10,
				'fond' => 'blanc',
				'colonnes' => 2,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Un cahier des charges défini avec vous',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Avant la première intervention, nous formalisons avec vous un cahier des charges précis : les espaces concernés, les tâches attendues dans chacun, la fréquence retenue, les horaires possibles et les points de vigilance propres à vos locaux (zones sensibles, matériel fragile, consignes de sécurité). Ce document sert de référence à l\'intervenant et à Audrey pour le suivi, et peut être ajusté à tout moment si vos besoins évoluent.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Intervenant habituel et continuité',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Nous privilégions, autant que possible, un intervenant habituel qui connaît vos locaux, vos consignes et vos habitudes. Cette continuité limite les oublis et accélère la prise en main. En cas d\'absence imprévue (congé, maladie), nous recherchons activement une solution de remplacement pour maintenir la prestation et vous tenons informé de l\'organisation retenue. Un intervenant habituel est recherché. En cas d\'absence, Top-Famille Pro recherche activement une solution selon les disponibilités.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 11,
				'fond' => '',
				'colonnes' => 4,
				'cartes' => array(
					'padding' => '22px',
					'rayon' => '14px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Comment se construit un cahier des charges',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'01',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Inventaire des espaces',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Chaque pièce est listée avec sa surface approximative, son revêtement de sol et son niveau de fréquentation. C\'est cet inventaire, et non une estimation au mètre carré, qui fonde le volume d\'heures.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'02',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Tâches et fréquences',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Pour chaque espace, on distingue ce qui est fait à chaque passage, une fois par semaine, ou une fois par mois. Cette hiérarchie sert de règle d\'arbitrage lorsqu\'un imprévu réduit le temps disponible.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'03',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Points de vigilance',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Matériaux fragiles, zones à accès réservé, matériel à ne pas toucher, documents à ne jamais déplacer, consignes de sécurité et d\'alarme. C\'est la partie qui évite les erreurs coûteuses au premier passage.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'04',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce qui est explicitement exclu',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Nous écrivons noir sur blanc ce qui ne fait pas partie de la prestation. Un périmètre clair évite l\'usure progressive de la relation, où les demandes s\'ajoutent sans que le temps prévu ne change.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Modifier la prestation en cours de route',
						'niveau' => 'h3',
						'grille' => false,
						'textes' => array(
							'Un déménagement, une embauche, une baisse d\'activité, une nouvelle salle de réunion, un passage en télétravail partiel : les besoins bougent. Une modification se demande simplement, par téléphone ou par e-mail à Audrey. Un ajustement de périmètre à volume d\'heures constant se met en place rapidement ; un changement de volume horaire donne lieu à un devis actualisé avant toute application. Aucune modification de tarif n\'est appliquée sans votre accord écrit préalable, et l\'arrêt de la prestation reste possible dans les conditions prévues au devis, sans engagement de durée.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 12,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Cahier des charges, intervenants et suivi',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous choisissons avec soin les personnes qui interviennent chez vous et privilégions la continuité autant que possible, sans en faire une garantie absolue.',
							'En cas d\'imprévu, nous recherchons activement une solution et vous informons de l\'organisation retenue et de son délai.',
							'Audrey suit votre dossier ; un cahier de liaison sur place trace consignes et remarques.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Voir notre fonctionnement en détail →',
								'route' => '#/notre-fonctionnement',
							),
						),
						'noms' => array(
							'Sélection & intervenant habituel recherché',
							'Recherche active d\'une solution en cas d\'absence',
							'Suivi & interlocuteur dédié',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 13,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'★★★★★',
							'· ·',
							'Marc V.',
							'Directeur administratif',
							'Chalon-sur-Saône',
						),
						'citations' => array(
							'« Nous avons comparé une embauche et un prestataire. Ce qui a tranché, c\'est le cahier des charges écrit noir sur blanc et le fait de savoir dès le départ ce qui n\'était pas inclus. »',
						),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 14,
				'fond' => 'blanc',
				'colonnes' => 3,
				'cartes' => array(
					'padding' => '24px',
					'rayon' => '16px',
					'fond' => 'rgb(244, 247, 248)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Trois situations concrètes',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Exemples représentatifs des demandes que nous recevons. Les volumes indiqués sont non contractuels : ils donnent un ordre de grandeur, pas un tarif.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'PME de 18 personnes, Dijon',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Un plateau, deux sanitaires, une salle de pause, une salle de réunion. Trois passages par semaine entre 6 h 30 et 8 h, soit environ 13 heures par mois. Sanitaires, cuisine et circulations à chaque passage ; bureaux et vitres intérieures en rotation. Accès par badge, alarme gérée par l\'intervenant.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Cabinet de groupe, Besançon',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Trois praticiens, une salle d\'attente commune, deux sanitaires. Passage quotidien à partir de 19 h 30, après le départ du dernier patient, soit environ 20 heures par mois. Salle d\'attente, accueil, sanitaires et surfaces de contact courantes chaque soir ; entretien courant des bureaux en rotation.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Remise en état après travaux, 80 m²',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Bureaux rénovés, cloisons déposées, peinture refaite. Une intervention unique estimée entre 6 et 8 heures : dépoussiérage descendant, vitres et encadrements, retrait des projections, sanitaires et coin cuisine, sols en dernier. Second passage court proposé 48 heures plus tard si nécessaire.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 15,
				'fond' => 'turquoise',
				'colonnes' => 3,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Le tarif, en toute transparence',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'27 € HT/h, identique en régulier et en ponctuel. S\'y ajoutent le cas échéant 9 € HT/mois de gestion, 50 € HT de frais de mise en place, le cas échéant, selon les conditions précisées au devis, une majoration de 10 % (dimanche, jours fériés, nuit) et 0,35 € HT/km.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Page Tarifs détaillée →',
								'route' => '#/nos-tarifs',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Nos départements',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Côte-d\'Or',
								'route' => '#/departement/cote-dor',
							),
							array(
								'texte' => 'Doubs',
								'route' => '#/departement/doubs',
							),
							array(
								'texte' => 'Jura',
								'route' => '#/departement/jura',
							),
							array(
								'texte' => 'Nièvre',
								'route' => '#/departement/nievre',
							),
							array(
								'texte' => 'Haute-Saône',
								'route' => '#/departement/haute-saone',
							),
							array(
								'texte' => 'Saône-et-Loire',
								'route' => '#/departement/saone-et-loire',
							),
							array(
								'texte' => 'Yonne',
								'route' => '#/departement/yonne',
							),
							array(
								'texte' => 'Territoire de Belfort',
								'route' => '#/departement/territoire-de-belfort',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Nos villes',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Dijon',
								'route' => '#/ville/dijon',
							),
							array(
								'texte' => 'Besançon',
								'route' => '#/ville/besancon',
							),
							array(
								'texte' => 'Dole',
								'route' => '#/ville/dole',
							),
							array(
								'texte' => 'Lons-le-Saunier',
								'route' => '#/ville/lons-le-saunier',
							),
							array(
								'texte' => 'Nevers',
								'route' => '#/ville/nevers',
							),
							array(
								'texte' => 'Vesoul',
								'route' => '#/ville/vesoul',
							),
							array(
								'texte' => 'Chalon-sur-Saône',
								'route' => '#/ville/chalon-sur-saone',
							),
							array(
								'texte' => 'Mâcon',
								'route' => '#/ville/macon',
							),
							array(
								'texte' => 'Hub régional →',
								'route' => '#/bourgogne-franche-comte',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 16,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Pour aller plus loin',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Tous les conseils →',
								'route' => '#/conseils',
							),
							array(
								'texte' => 'À quelle fréquence faire nettoyer ses bureaux ?→',
								'route' => '#/article/frequence-bureaux',
							),
							array(
								'texte' => 'Combien coûte le nettoyage de bureaux ?→',
								'route' => '#/article/cout-nettoyage-bureaux',
							),
							array(
								'texte' => 'Comment rédiger un cahier des charges de nettoyage ?→',
								'route' => '#/article/cahier-des-charges-nettoyage',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 17,
				'fond' => 'alt',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Questions fréquentes',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(
							array(
								'question' => 'Intervenez-vous dans toute la Bourgogne-Franche-Comté ?',
								'reponse' => 'Oui, depuis Saint-Apollinaire sur les huit départements. Selon la distance, des indemnités kilométriques de 0,35 € HT/km peuvent s\'appliquer et sont indiquées au devis.',
							),
							array(
								'question' => 'Faut-il fournir les produits et le matériel ?',
								'reponse' => 'Les produits et le matériel sont généralement fournis par le client. Les modalités sont précisées au devis.',
							),
							array(
								'question' => 'Le devis est-il payant ou engageant ?',
								'reponse' => 'Le devis est gratuit, transmis sous 24 heures, et sans engagement de votre part.',
							),
							array(
								'question' => 'Que se passe-t-il si l\'intervenant est absent ?',
								'reponse' => 'Nous recherchons une solution de remplacement pour maintenir la continuité et vous tenons informé.',
							),
							array(
								'question' => 'Comment est rédigé le cahier des charges ?',
								'reponse' => 'Il est établi avec vous avant la première intervention : espaces, tâches, fréquence, horaires et points de vigilance propres à vos locaux. Il peut être ajusté à tout moment.',
							),
							array(
								'question' => 'Le même intervenant vient-il à chaque passage ?',
								'reponse' => 'C\'est l\'organisation que nous recherchons : un intervenant habituel qui connaît vos locaux et vos consignes. Cette continuité est privilégiée autant que possible, sans constituer une garantie absolue en cas d\'absence ou de changement de disponibilité.',
							),
							array(
								'question' => 'Vaut-il mieux passer par un prestataire ou embaucher un agent d\'entretien ?',
								'reponse' => 'Le recrutement direct peut se justifier à partir d\'un volume horaire important et d\'un besoin de présence continue. En dessous, le coût réel d\'une embauche — recrutement, paie, congés, remplacement, matériel, encadrement — dépasse souvent l\'écart de tarif horaire. Si votre besoin est une présence permanente, nous vous le dirons plutôt que de forcer un devis.',
							),
							array(
								'question' => 'Comment modifier la prestation en cours de contrat ?',
								'reponse' => 'Par un simple échange avec Audrey. Un ajustement de périmètre à volume d\'heures constant se met en place rapidement ; un changement de volume horaire donne lieu à un devis actualisé, soumis à votre accord avant application. Il n\'y a pas d\'engagement de durée.',
							),
							array(
								'question' => 'Quelle fréquence faut-il prévoir pour des bureaux ?',
								'reponse' => 'Elle dépend surtout de l\'effectif réellement présent, du nombre de sanitaires et de la présence d\'une cuisine. Deux à trois passages par semaine constituent le rythme le plus courant entre dix et trente postes ; au-delà, les sanitaires et la cuisine justifient généralement un passage quotidien.',
							),
							array(
								'question' => 'Pouvez-vous intervenir le dimanche ou la nuit ?',
								'reponse' => 'Oui, sur demande, lorsque votre activité l\'exige. Ces créneaux font l\'objet d\'une majoration de 10 % du tarif horaire, indiquée à l\'avance sur le devis et jamais découverte après coup.',
							),
						),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 18,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Un projet d\'entretien pour vos locaux ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Devis gratuit sous 24 h, sans engagement.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ nettoyage-professionnel (17 sections)\n";

update_option( 'tfp_page_prestations', array(
		'h1' => 'Nos prestations de nettoyage professionnel',
		'lede' => array(
			'Un même savoir-faire, adapté à chaque type de locaux. Toutes nos prestations sont réalisées par des intervenants sélectionnés, au tarif de 27 € HT/h, en régulier ou en ponctuel.',
			'Chaque prestation ci-dessous correspond à un type de local et à des contraintes propres : horaires d\'ouverture, confidentialité, accès au public, rotation d\'occupants. Nous ne proposons pas un forfait générique décliné en six versions, mais six organisations réellement pensées pour leur contexte — avec, dans chaque cas, un cahier des charges défini avec vous, un intervenant sélectionné et un tarif identique de 27 € HT/h.',
		),
		'hero_alt' => '',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Comment choisir la bonne prestation ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(
							array(
								'question' => 'Vous avez des équipes sur place ?',
								'reponse' => 'Bureaux ou cabinets/professions libérales, selon que vous recevez du public ou non.',
							),
							array(
								'question' => 'Vous recevez des clients en boutique ?',
								'reponse' => 'Nettoyage de commerces, avec passage avant ouverture.',
							),
							array(
								'question' => 'Vous gérez un immeuble ou une résidence ?',
								'reponse' => 'Copropriétés et parties communes, en lien avec le syndic.',
							),
							array(
								'question' => 'Vous louez un bien meublé ?',
								'reponse' => 'Locations meublées, entre deux occupants.',
							),
							array(
								'question' => 'Vous sortez de travaux ou déménagez ?',
								'reponse' => 'Nettoyage ponctuel et remise en état, sans engagement de suite.',
							),
							array(
								'question' => 'Vous hésitez encore ?',
								'reponse' => 'Décrivez-nous vos locaux : Audrey vous oriente vers la formule adaptée.',
							),
						),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 2,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Ce qui est commun aux six prestations',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Quel que soit le type de locaux, l\'organisation est la même : un cahier des charges écrit et validé avec vous avant le premier passage, un intervenant sélectionné dont nous recherchons la continuité d\'un passage à l\'autre, un cahier de liaison laissé sur place pour tracer ce qui a été fait et ce qui n\'a pas pu l\'être, et Audrey comme interlocutrice unique du devis au suivi. Le tarif est identique — 27 € HT/h en régulier comme en ponctuel — et les frais éventuels sont annoncés avant le devis plutôt que découverts sur une facture.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce qui change d\'une prestation à l\'autre',
						'niveau' => 'h2',
						'grille' => true,
						'textes' => array(
							'Ce sont les contraintes qui diffèrent, et elles déterminent tout : l\'heure du passage, l\'ordre des priorités, la gestion des accès, le périmètre exclu. Un commerce se traite avant l\'ouverture sur un créneau non extensible ; un cabinet, après le départ du dernier patient ; une copropriété, à jour fixe validé par le syndic ; un meublé, sur le créneau disponible entre deux occupants. Chaque page détaille ces contraintes, une semaine type et les limites explicites de la prestation.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Nettoyage de bureaux',
							'Un entretien régulier et discret de vos espaces de travail, confié autant que possible à un intervenant habituel, pour des bureaux toujours prêts à recevoir vos équipes et vos visiteurs.',
							'En savoir plus →',
							'Nettoyage de commerces',
							'Une surface de vente impeccable à l\'ouverture : sols, vitrines et sanitaires clients entretenus avant l\'arrivée de vos premiers visiteurs.',
							'En savoir plus →',
							'Cabinets & professions libérales',
							'L\'entretien courant des cabinets médicaux, paramédicaux, juridiques et de conseil : accueil, salle d\'attente, bureaux, sanitaires et sols, en dehors des heures de consultation et dans le respect de la confidentialité.',
							'En savoir plus →',
							'Copropriétés & parties communes',
							'L\'entretien régulier des halls, cages d\'escalier, ascenseurs et locaux communs, pour des résidences et immeubles tertiaires soignés au quotidien.',
							'En savoir plus →',
							'Locations meublées & hébergements',
							'La remise en état de vos meublés et hébergements professionnels entre deux occupants, avec un contrôle visuel et un signalement des anomalies selon l\'organisation définie avec le client.',
							'En savoir plus →',
							'Nettoyage ponctuel & remise en état',
							'Une intervention ponctuelle pour une remise en état après travaux, un grand nettoyage saisonnier ou une fin de bail, au même tarif horaire que nos prestations régulières.',
							'En savoir plus →',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Besoin d\'aide pour choisir ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Décrivez vos locaux : Audrey identifie avec vous la formule adaptée et vous répond sous 24 h.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ prestations (4 sections)\n";

update_option( 'tfp_page_zones-intervention', array(
		'h1' => 'Nos zones d\'intervention en Bourgogne-Franche-Comté',
		'lede' => array(
			'Top-Famille Pro entretient bureaux, commerces, cabinets, parties communes et locations meublées dans les huit départements de la Bourgogne-Franche-Comté, depuis son implantation de Saint-Apollinaire, près de Dijon.',
		),
		'hero_alt' => '',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Voir les tarifs →',
								'route' => '#/nos-tarifs',
							),
						),
						'noms' => array(
							'27 € HT/h',
							'tarif unique en région',
							'Devis gratuit sous 24 h',
							'Intervention régulière ou ponctuelle',
							'Conditions d\'arrêt précisées au devis',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous intervenons uniquement en Bourgogne-Franche-Comté : Côte-d\'Or, Doubs, Jura, Nièvre, Haute-Saône, Saône-et-Loire, Yonne et Territoire de Belfort. Le tarif est le même partout, 27 € HT/h, en entretien régulier comme en intervention ponctuelle, avec un devis gratuit transmis sous 24 heures. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Réponse directe',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => array(
					'padding' => '32px',
					'rayon' => '18px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 3,
					'tuile' => true,
				),
				'blocs' => array(
					array(
						'titre' => 'Une couverture régionale organisée depuis Saint-Apollinaire',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Top-Famille Pro est implantée à Saint-Apollinaire, commune de la périphérie est de Dijon, en Côte-d\'Or. C\'est de cette adresse que partent les plannings, que sont préparés les devis et que sont cherchées les solutions de remplacement. Nous n\'avons pas d\'agence à Besançon, à Chalon-sur-Saône ni ailleurs dans la région : une seule adresse, une seule interlocutrice, un seul numéro de téléphone pour tous nos clients.',
							'Cette organisation a une conséquence concrète : les conditions d\'intervention dépendent de la distance réelle entre vos locaux et Saint-Apollinaire, et non d\'un tarif différent affiché ville par ville. Le taux horaire reste de 27 € HT/h dans toute la région. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Comment nous organisons les déplacements',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le regroupement des interventions par secteur et par journée est étudié selon le planning. Un intervenant qui travaille sur l\'agglomération dijonnaise peut enchaîner des sites proches les uns des autres ; sur les secteurs plus éloignés, nous privilégions des créneaux plus longs et des fréquences régulières, ce qui limite les trajets et stabilise le planning. C\'est aussi ce qui nous permet de tenir un tarif unique dans toute la région.',
							'Pour vous, cela signifie que la première question posée au téléphone porte sur votre adresse exacte, la surface concernée et le rythme souhaité. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce qui change selon votre adresse',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous ne pratiquons pas de tarif à la carte selon la commune, mais l\'organisation n\'est pas identique partout. Voici ce qui varie réellement :',
						),
						'liste' => array(
							'Agglomération dijonnaise : créneaux souples, passages courts possibles, organisation étudiée selon le planning',
							'Villes principales de la région : passages regroupés, planning convenu à l\'avance',
							'Communes plus éloignées : fréquence hebdomadaire ou bimensuelle privilégiée',
							'Interventions ponctuelles : selon disponibilité, avec une date confirmée au devis',
							'Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Bourgogne-Franche-ComtéLa page régionale · huit départements couverts depuis Saint-ApollinaireVoir la page régionale →',
								'route' => '#/bourgogne-franche-comte',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 6,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les huit départements',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Chaque département a sa page : villes couvertes, tissu professionnel, organisation des déplacements et questions fréquentes.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Côte-d\'Or21Préfecture : DijonVoir le département →',
								'route' => '#/departement/cote-dor',
							),
							array(
								'texte' => 'Doubs25Préfecture : BesançonVoir le département →',
								'route' => '#/departement/doubs',
							),
							array(
								'texte' => 'Jura39Préfecture : Lons-le-SaunierVoir le département →',
								'route' => '#/departement/jura',
							),
							array(
								'texte' => 'Nièvre58Préfecture : NeversVoir le département →',
								'route' => '#/departement/nievre',
							),
							array(
								'texte' => 'Haute-Saône70Préfecture : VesoulVoir le département →',
								'route' => '#/departement/haute-saone',
							),
							array(
								'texte' => 'Saône-et-Loire71Préfecture : MâconVoir le département →',
								'route' => '#/departement/saone-et-loire',
							),
							array(
								'texte' => 'Yonne89Préfecture : AuxerreVoir le département →',
								'route' => '#/departement/yonne',
							),
							array(
								'texte' => 'Territoire de Belfort90Préfecture : BelfortVoir le département →',
								'route' => '#/departement/territoire-de-belfort',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 7,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Nos dix villes principales',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Pages détaillées : prestations, espaces traités, fréquences, quartiers et zones d\'activité, communes proches.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Dijon21000',
								'route' => '#/ville/dijon',
							),
							array(
								'texte' => 'Besançon25000',
								'route' => '#/ville/besancon',
							),
							array(
								'texte' => 'Dole39100',
								'route' => '#/ville/dole',
							),
							array(
								'texte' => 'Lons-le-Saunier39000',
								'route' => '#/ville/lons-le-saunier',
							),
							array(
								'texte' => 'Nevers58000',
								'route' => '#/ville/nevers',
							),
							array(
								'texte' => 'Vesoul70000',
								'route' => '#/ville/vesoul',
							),
							array(
								'texte' => 'Chalon-sur-Saône71100',
								'route' => '#/ville/chalon-sur-saone',
							),
							array(
								'texte' => 'Mâcon71000',
								'route' => '#/ville/macon',
							),
							array(
								'texte' => 'Auxerre89000',
								'route' => '#/ville/auxerre',
							),
							array(
								'texte' => 'Belfort90000',
								'route' => '#/ville/belfort',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 8,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Premières communes secondaires',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Autour de Dijon et de Beaune, ces communes disposent déjà de leur page. D\'autres suivront selon les demandes reçues.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Saint-Apollinaire21850',
								'route' => '#/ville/saint-apollinaire',
							),
							array(
								'texte' => 'Chenôve21300',
								'route' => '#/ville/chenove',
							),
							array(
								'texte' => 'Quetigny21800',
								'route' => '#/ville/quetigny',
							),
							array(
								'texte' => 'Talant21240',
								'route' => '#/ville/talant',
							),
							array(
								'texte' => 'Longvic21600',
								'route' => '#/ville/longvic',
							),
							array(
								'texte' => 'Fontaine-lès-Dijon21121',
								'route' => '#/ville/fontaine-les-dijon',
							),
							array(
								'texte' => 'Marsannay-la-Côte21160',
								'route' => '#/ville/marsannay-la-cote',
							),
							array(
								'texte' => 'Beaune21200',
								'route' => '#/ville/beaune',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 9,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => array(
					'padding' => '32px',
					'rayon' => '18px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Départements, villes et communes : comment lire ces pages',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Chaque département dispose de sa page : villes couvertes, tissu professionnel local, types de locaux les plus fréquents, organisation des déplacements et questions fréquentes. Chaque ville principale a également la sienne, plus détaillée : espaces et tâches, fréquences, horaires, accès aux locaux, exemple de budget, quartiers et zones d\'activité, communes réellement proches.',
							'Nous distinguons volontairement trois niveaux de proximité : les communes voisines, les autres villes du même département, et les autres secteurs couverts en région. Besançon, Nevers ou Vesoul sont des secteurs régionaux couverts, pas des communes voisines de Dijon : nous préférons l\'écrire clairement plutôt que de gonfler artificiellement une liste de liens.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les espaces que nous traitons — et ceux que nous ne traitons pas',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Notre offre couvre les bureaux, les accueils, les locaux administratifs, les parties communes d\'immeubles, les commerces et les cabinets courants. Lorsqu\'une zone d\'activité accueille de l\'industrie, de la logistique, de l\'agroalimentaire ou des établissements de santé, nous intervenons uniquement sur les espaces compatibles avec cette offre : bureaux administratifs, salles de réunion, vestiaires de bureau, halls et sanitaires.',
							'Nous ne réalisons pas de nettoyage industriel lourd, de nettoyage de chaînes de production, de nettoyage agroalimentaire spécialisé, de bio-nettoyage hospitalier, de traitement chimique, de désamiantage ni d\'intervention en locaux à risque. Si votre besoin relève de ces domaines, nous le disons dès le premier échange plutôt que de vous faire perdre du temps.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Votre commune n\'apparaît pas encore ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Les pages publiées correspondent à nos secteurs prioritaires. Elles ne délimitent pas notre périmètre : nous intervenons dans de nombreuses communes qui n\'ont pas encore de page dédiée, dès lors que le trajet et la fréquence permettent une organisation stable.',
							'Le plus simple reste de nous donner votre adresse et votre besoin : nous vous confirmons sous 24 heures si nous pouvons intervenir, à quel rythme, et à quelles conditions. Si nous ne sommes pas en mesure de tenir un planning fiable chez vous, nous vous le disons plutôt que de nous engager à moitié.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 10,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Découvrir nos prestationsBureaux, commerces, cabinets, copropriétés, locations meublées, ponctuel.',
								'route' => '#/nos-prestations',
							),
							array(
								'texte' => 'Voir les tarifs27 € HT/h, gestion et mise en place détaillées.',
								'route' => '#/nos-tarifs',
							),
							array(
								'texte' => 'Notre fonctionnementCahier des charges, sélection, suivi, remplacement.',
								'route' => '#/notre-fonctionnement',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 11,
				'fond' => 'turquoise',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Questions fréquentes sur nos zones d\'intervention',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(
							array(
								'question' => 'Intervenez-vous dans toute la France ?',
								'reponse' => 'Non. Top-Famille Pro intervient exclusivement en Bourgogne-Franche-Comté, sur ses huit départements. Nous préférons couvrir correctement une région que d\'annoncer une présence nationale que nous ne pourrions pas tenir.',
							),
							array(
								'question' => 'Avez-vous des agences locales dans la région ?',
								'reponse' => 'Non, et nous ne cherchons pas à le faire croire. Nous avons une seule implantation, à Saint-Apollinaire près de Dijon, et une seule interlocutrice, Audrey, joignable au 06 36 17 63 39 depuis n\'importe quelle commune de la région.',
							),
							array(
								'question' => 'Le tarif change-t-il selon la ville ?',
								'reponse' => 'Non, le taux horaire est de 27 € HT/h partout. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis. Tout figure au devis.',
							),
							array(
								'question' => 'À partir de quelle fréquence intervenez-vous ?',
								'reponse' => 'Nous organisons aussi bien un passage hebdomadaire que plusieurs passages par semaine. Sur les communes éloignées de Saint-Apollinaire, une fréquence régulière est préférable à des passages isolés : cela nous permet de tenir un planning fiable et un intervenant habituel.',
							),
							array(
								'question' => 'Ma commune n\'est pas listée sur le site, est-ce un problème ?',
								'reponse' => 'Non. Les pages en ligne couvrent nos secteurs prioritaires, pas la totalité de notre périmètre. Donnez-nous votre adresse : nous confirmons sous 24 heures si nous pouvons intervenir et à quelles conditions.',
							),
							array(
								'question' => 'Puis-je faire appel à vous pour une intervention unique ?',
								'reponse' => 'Oui. Nous réalisons des interventions ponctuelles : remise en état après travaux, fin de bail, avant ouverture, grand nettoyage saisonnier. Le tarif reste de 27 € HT/h et la date est confirmée au devis, selon nos disponibilités sur votre secteur.',
							),
						),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 12,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Votre commune est-elle couverte ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Dites-nous votre adresse : nous confirmons notre intervention et vous transmettons un devis gratuit sous 24 h.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Vérifier notre intervention dans ma commune',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ zones-intervention (11 sections)\n";

update_option( 'tfp_page_bourgogne-franche-comte', array(
		'h1' => 'Entreprise de nettoyage en Bourgogne-Franche-Comté',
		'lede' => array(
			'Basée à Saint-Apollinaire, Top-Famille Pro entretient bureaux, commerces, cabinets, parties communes et locations meublées sur les huit départements de la région, avec une même organisation et un même tarif de 27 € HT/h.',
		),
		'hero_alt' => 'Locaux professionnels en Bourgogne-Franche-Comté',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Voir les tarifs →',
								'route' => '#/nos-tarifs',
							),
						),
						'noms' => array(
							'27 € HT/h',
							'tarif unique en région',
							'Devis gratuit sous 24 h',
							'Intervention régulière ou ponctuelle',
							'Conditions d\'arrêt précisées au devis',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Top-Famille Pro est une entreprise de nettoyage régionale implantée à Saint-Apollinaire (21850), près de Dijon. Elle intervient en Bourgogne-Franche-Comté auprès des TPE, PME, commerces, professions libérales, syndics et propriétaires bailleurs, en entretien régulier ou en intervention ponctuelle, au tarif de 27 € HT/h, avec un devis gratuit transmis sous 24 heures et une interlocutrice unique, Audrey, au 06 36 17 63 39.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Réponse directe',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => array(
					'padding' => '32px',
					'rayon' => '18px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 3,
					'tuile' => true,
				),
				'blocs' => array(
					array(
						'titre' => 'Notre implantation réelle : Saint-Apollinaire, près de Dijon',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Top-Famille Pro n\'est pas une enseigne nationale déclinée en franchises. L\'entreprise est installée à Saint-Apollinaire, commune limitrophe de Dijon en Côte-d\'Or, et c\'est de là que tout est organisé : rendez-vous de visite, cahiers des charges, plannings, recherche de remplacement, suivi mensuel. Audrey est l\'interlocutrice de tous les clients, quel que soit leur département.',
							'Nous le précisons parce que le secteur du nettoyage compte beaucoup de sites annonçant une « agence » dans chaque ville. Chez nous, il n\'y en a qu\'une, et le numéro affiché est le même partout : 06 36 17 63 39. Vous savez donc exactement qui vous appelez et qui suivra votre dossier dans six mois.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Le territoire que nous couvrons — et celui que nous ne couvrons pas',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous intervenons sur les huit départements de la Bourgogne-Franche-Comté : Côte-d\'Or, Doubs, Jura, Nièvre, Haute-Saône, Saône-et-Loire, Yonne et Territoire de Belfort. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
							'À l\'intérieur de la région, la densité de nos interventions n\'est pas uniforme. L\'agglomération dijonnaise est notre secteur prioritaire ; les autres pôles urbains — Besançon, Chalon-sur-Saône, Mâcon, Dole, Auxerre, Nevers, Lons-le-Saunier, Vesoul, Belfort — sont couverts avec des plannings regroupés. Les communes intermédiaires sont traitées au cas par cas, selon le trajet et la fréquence.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les professionnels que nous accompagnons',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Parmi les professionnels susceptibles de faire appel à Top-Famille Pro, on trouve surtout des structures qui n\'ont pas de service d\'entretien interne et qui cherchent un prestataire joignable directement, pas un centre d\'appels. Concrètement :',
						),
						'liste' => array(
							'TPE et PME : bureaux, open-spaces, salles de réunion, locaux techniques administratifs',
							'Commerces et boutiques : surfaces de vente, réserves, sanitaires, vitrines intérieures',
							'Professions libérales et cabinets : cabinets médicaux courants, dentaires, avocats, experts-comptables',
							'Syndics et conseils syndicaux : halls, cages d\'escalier, ascenseurs, locaux poubelles',
							'Propriétaires bailleurs et gestionnaires : locations meublées, entre deux séjours',
							'Associations, agences, coworkings et structures de formation',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les types de locaux les plus fréquents en région',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Un plateau de bureaux dijonnais, une boutique de centre-ville à Besançon, un cabinet dentaire à Chalon-sur-Saône ou une copropriété de Beaune ne demandent ni le même matériel, ni les mêmes horaires, ni la même fréquence. Le cahier des charges est donc établi local par local, après visite ou après un échange détaillé si le site est éloigné.',
						),
						'liste' => array(
							'Plateaux de bureaux et open-spaces',
							'Locaux d\'accueil et salles d\'attente',
							'Surfaces de vente et réserves',
							'Cabinets paramédicaux et dentaires courants',
							'Parties communes d\'immeubles',
							'Locations meublées et logements de courte durée',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Notre organisation à l\'échelle régionale',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le regroupement des interventions par secteur est étudié selon le planning : un même intervenant peut enchaîner plusieurs sites proches sur une même journée, ce qui réduit les trajets et permet de tenir le tarif régional unique. Sur les départements les plus éloignés, nous privilégions des créneaux plus longs et des fréquences stables plutôt qu\'une multiplication de passages courts.',
							'Chaque site dispose d\'un cahier de liaison, sur place ou numérique, où l\'intervenant note ce qui a été fait et ce qui mérite votre attention : consommable à recommander, dégât constaté, accès défectueux. Vous n\'avez pas besoin d\'être présent pour savoir ce qui s\'est passé.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => 'navy',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Nos prestations partout en Bourgogne-Franche-Comté',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Six prestations, un seul interlocuteur. Nous intervenons sur les espaces compatibles avec notre offre : bureaux, accueils, locaux administratifs, parties communes, commerces et cabinets courants.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Nettoyage de bureauxOpen-spaces, salles de réunion, accueil',
								'route' => '#/service/bureaux',
							),
							array(
								'texte' => 'Nettoyage de commercesBoutiques, showrooms, surfaces de vente',
								'route' => '#/service/commerces',
							),
							array(
								'texte' => 'Cabinets & professions libéralesSanté, droit, conseil, salles d\'attente',
								'route' => '#/service/cabinets',
							),
							array(
								'texte' => 'Copropriétés & parties communesHalls, cages d\'escalier, locaux techniques',
								'route' => '#/service/coproprietes',
							),
							array(
								'texte' => 'Locations meublées & hébergementsMeublés, gîtes, hébergements pro',
								'route' => '#/service/meubles',
							),
							array(
								'texte' => 'Nettoyage ponctuel & remise en étatAprès travaux, grand nettoyage, départ',
								'route' => '#/service/ponctuel',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 6,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les huit départements couverts',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Une couverture régionale réelle, organisée depuis un seul point d\'attache à Saint-Apollinaire — sans agences locales.',
							'De la métropole dijonnaise aux zones d\'activité de la Côte, nous entretenons bureaux, commerces et copropriétés partout en Côte-d\'Or.',
							'Besançon et son agglomération, cœur de notre présence dans le Doubs pour l\'entretien des locaux professionnels.',
							'Dole, Lons-le-Saunier et les bassins d\'activité du Jura, pour un entretien régulier ou ponctuel de vos locaux.',
							'Nevers et son agglomération, pour l\'entretien de vos bureaux, commerces et cabinets dans la Nièvre.',
							'Vesoul et les zones d\'activité de la Haute-Saône, pour un entretien fiable de vos locaux professionnels.',
							'De Chalon-sur-Saône à Mâcon, le long de l\'axe Saône, pour l\'entretien de vos bureaux et commerces.',
							'Auxerre et le nord de la région, aux portes de l\'Île-de-France, pour l\'entretien de vos locaux.',
							'Belfort et son agglomération industrielle et universitaire, pour l\'entretien de vos locaux professionnels.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Côte-d\'Or',
							'21',
							'Préfecture :',
							'Dijon',
							'Voir le département →',
							'Doubs',
							'25',
							'Préfecture :',
							'Besançon',
							'Voir le département →',
							'Jura',
							'39',
							'Préfecture :',
							'Lons-le-Saunier',
							'Voir le département →',
							'Nièvre',
							'58',
							'Préfecture :',
							'Nevers',
							'Voir le département →',
							'Haute-Saône',
							'70',
							'Préfecture :',
							'Vesoul',
							'Voir le département →',
							'Saône-et-Loire',
							'71',
							'Préfecture :',
							'Mâcon',
							'Voir le département →',
							'Yonne',
							'89',
							'Préfecture :',
							'Auxerre',
							'Voir le département →',
							'Territoire de Belfort',
							'90',
							'Préfecture :',
							'Belfort',
							'Voir le département →',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 7,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Nos dix villes principales',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Dijon21000',
								'route' => '#/ville/dijon',
							),
							array(
								'texte' => 'Besançon25000',
								'route' => '#/ville/besancon',
							),
							array(
								'texte' => 'Dole39100',
								'route' => '#/ville/dole',
							),
							array(
								'texte' => 'Lons-le-Saunier39000',
								'route' => '#/ville/lons-le-saunier',
							),
							array(
								'texte' => 'Nevers58000',
								'route' => '#/ville/nevers',
							),
							array(
								'texte' => 'Vesoul70000',
								'route' => '#/ville/vesoul',
							),
							array(
								'texte' => 'Chalon-sur-Saône71100',
								'route' => '#/ville/chalon-sur-saone',
							),
							array(
								'texte' => 'Mâcon71000',
								'route' => '#/ville/macon',
							),
							array(
								'texte' => 'Auxerre89000',
								'route' => '#/ville/auxerre',
							),
							array(
								'texte' => 'Belfort90000',
								'route' => '#/ville/belfort',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Secteurs secondaires déjà documentés',
						'niveau' => 'h3',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Saint-Apollinaire',
								'route' => '#/ville/saint-apollinaire',
							),
							array(
								'texte' => 'Chenôve',
								'route' => '#/ville/chenove',
							),
							array(
								'texte' => 'Quetigny',
								'route' => '#/ville/quetigny',
							),
							array(
								'texte' => 'Talant',
								'route' => '#/ville/talant',
							),
							array(
								'texte' => 'Longvic',
								'route' => '#/ville/longvic',
							),
							array(
								'texte' => 'Fontaine-lès-Dijon',
								'route' => '#/ville/fontaine-les-dijon',
							),
							array(
								'texte' => 'Marsannay-la-Côte',
								'route' => '#/ville/marsannay-la-cote',
							),
							array(
								'texte' => 'Beaune',
								'route' => '#/ville/beaune',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 8,
				'fond' => 'turquoise',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Un tarif régional unique',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le taux horaire est de 27 € HT/h dans les huit départements, en régulier comme en ponctuel. S\'y ajoutent 9 € HT/mois de gestion pour les contrats réguliers, 50 € HT de frais de mise en place, le cas échéant, selon les conditions précisées au devis, et, le cas échéant, des indemnités kilométriques de 0,35 € HT/km. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Aucun de ces éléments n\'apparaît après coup : tout est écrit au devis.',
							'12 h × 27 € HT + 9 € HT de gestion = 333 € HT/mois. Premier mois : 383 € HT si les frais de mise en place s\'appliquent. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Voir les tarifs →',
								'route' => '#/nos-tarifs',
							),
						),
						'noms' => array(
							'Exemple · bureaux réguliers, 12 h/mois',
							'333',
							'HT/mois',
							'Exemple non contractuel.',
							'★★★★★',
							'Sophie M.',
							'Cabinet comptable · Côte-d\'Or',
							'Avis de démonstration régional (demo: true) — à remplacer par un avis réel.',
						),
						'citations' => array(
							'« Nous avions besoin d\'un prestataire capable de suivre trois sites dans deux départements sans multiplier les interlocuteurs. Le planning est tenu et les consignes circulent bien entre les passages. »',
						),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 9,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => array(
					'padding' => '32px',
					'rayon' => '18px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Sélection des intervenants et suivi',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Les intervenants sont recrutés par Audrey, en entretien individuel, avec vérification des références et une période d\'observation sur site. Nous cherchons à confier un site au même intervenant d\'une semaine sur l\'autre : c\'est ce qui fait la différence sur la qualité, parce qu\'une personne qui connaît vos locaux repère ce qu\'un remplaçant ne verra pas.',
							'En cas d\'absence, de congés ou de départ, nous cherchons une solution de remplacement et nous vous prévenons du changement. Nous ne promettons pas une continuité automatique : nous nous engageons à vous informer, à transmettre les consignes écrites au remplaçant et à repasser sur site si nécessaire.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Entretien régulier ou intervention ponctuelle',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'L\'entretien régulier représente l\'essentiel de notre activité : un à cinq passages par semaine, un volume d\'heures défini, un planning convenu et un tarif mensuel prévisible. C\'est le format qui donne les meilleurs résultats, parce que l\'intervenant connaît le site et que les consignes s\'affinent au fil des semaines.',
							'L\'intervention ponctuelle répond à un besoin daté : remise en état après travaux, fin de bail, avant ouverture, grand nettoyage saisonnier, nettoyage après sinistre léger. Le tarif horaire est identique, 27 € HT/h, avec une estimation du volume d\'heures nécessaire au devis et une date confirmée selon nos disponibilités sur le secteur.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Ce que nous ne faisons pas',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'La Bourgogne-Franche-Comté est une région industrielle, avec de la métallurgie, de l\'automobile, de la plasturgie, de l\'agroalimentaire, de la logistique et des établissements de santé importants. Sur ces sites, nous intervenons uniquement dans les espaces compatibles avec notre offre : bureaux administratifs, accueils, salles de réunion, sanitaires et vestiaires de bureau.',
							'Nous ne réalisons pas de nettoyage industriel lourd, ni de nettoyage de chaînes de production, ni de nettoyage agroalimentaire spécialisé, ni de bio-nettoyage hospitalier, ni de traitement chimique, ni de désamiantage, ni d\'intervention en locaux à risque. Ces prestations relèvent d\'entreprises spécialisées, avec des protocoles et des habilitations que nous n\'avons pas.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Comment démarre une collaboration',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Tout commence par un appel ou une demande de devis en ligne. Nous parlons de votre adresse, de la surface, des espaces concernés, du rythme souhaité et de vos contraintes d\'horaires. Une visite est organisée quand la configuration le justifie ; sinon, un échange précis et quelques photos suffisent pour établir un cahier des charges honnête.',
							'Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis, qui reste gratuit et sans engagement. Les conditions d\'arrêt de la prestation y figurent également. Si l\'organisation ne convient pas après quelques semaines, elle est ajustée — c\'est plus simple que de renégocier un contrat annuel.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 10,
				'fond' => 'turquoise',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Questions fréquentes — Bourgogne-Franche-Comté',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(
							array(
								'question' => 'Intervenez-vous dans les huit départements de la région ?',
								'reponse' => 'Oui : Côte-d\'Or, Doubs, Jura, Nièvre, Haute-Saône, Saône-et-Loire, Yonne et Territoire de Belfort. En revanche, nous n\'intervenons pas en dehors de la Bourgogne-Franche-Comté.',
							),
							array(
								'question' => 'Où est réellement située l\'entreprise ?',
								'reponse' => 'À Saint-Apollinaire (21850), commune limitrophe de Dijon, en Côte-d\'Or. C\'est notre unique implantation : nous n\'avons pas d\'agences dans les autres villes de la région.',
							),
							array(
								'question' => 'Le tarif est-il le même dans tous les départements ?',
								'reponse' => 'Oui, 27 € HT/h partout, en régulier comme en ponctuel, avec 9 € HT/mois de gestion et 50 € HT de frais de mise en place, le cas échéant, selon les conditions précisées au devis. Les éventuelles indemnités kilométriques dépendent de l\'adresse des locaux, du planning et des conditions d\'intervention. Elles sont précisées dans le devis.',
							),
							array(
								'question' => 'Aurai-je toujours le même intervenant ?',
								'reponse' => 'C\'est ce que nous recherchons pour chaque site, car la régularité fait la qualité. Nous ne le garantissons pas : en cas d\'absence ou de départ, nous cherchons un remplacement, transmettons les consignes écrites et vous informons du changement.',
							),
							array(
								'question' => 'Faites-vous du nettoyage industriel ou hospitalier ?',
								'reponse' => 'Non. Nous intervenons sur les bureaux, accueils, locaux administratifs, parties communes, commerces et cabinets courants. Le nettoyage industriel lourd, l\'agroalimentaire spécialisé, le bio-nettoyage hospitalier et le désamiantage ne font pas partie de notre offre.',
							),
							array(
								'question' => 'Faut-il signer un engagement de durée ?',
								'reponse' => 'Le devis est gratuit et sans engagement. Pour la prestation, le volume d\'heures et la fréquence peuvent être ajustés, et les conditions d\'arrêt figurent au devis avant signature — vous pouvez arrêter en respectant un simple préavis écrit.',
							),
							array(
								'question' => 'Qui contacter pour un site situé loin de Dijon ?',
								'reponse' => 'La même personne : Audrey, au 06 36 17 63 39. Nous n\'utilisons pas de numéro local différent selon la ville, et votre dossier n\'est pas transféré à un autre interlocuteur.',
							),
						),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 11,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Vos locaux, où que vous soyez en région',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Devis gratuit sous 24 h, sans engagement, au même tarif de 27 € HT/h.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander un devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ bourgogne-franche-comte (10 sections)\n";

update_option( 'tfp_page_pourquoi-nous', array(
		'h1' => 'Pourquoi choisir Top-Famille Pro',
		'lede' => array(
			'La rigueur d\'un prestataire structuré, avec la proximité d\'une entreprise régionale directement joignable. Voici ce qui fait la différence, preuves à l\'appui.',
			'Beaucoup de dirigeants et de gestionnaires nous contactent après une expérience décevante : un prestataire injoignable, un intervenant qui change sans prévenir, un tarif découvert trop tard. Nous avons construit notre organisation pour répondre précisément à ces frustrations, plutôt que d\'empiler des promesses commerciales.',
		),
		'hero_alt' => '',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Audrey est votre interlocutrice identifiée du premier contact au suivi dans la durée. Elle connaît votre dossier, vos consignes et l\'historique de vos échanges — vous ne répétez jamais votre situation à un nouvel interlocuteur anonyme.',
							'Nous choisissons avec soin les personnes qui interviennent dans vos locaux, en particulier leur fiabilité et leur sérieux, et recherchons un intervenant habituel qui connaît vos habitudes, continuité privilégiée autant que possible sans être garantie de façon absolue.',
							'Un cahier de liaison reste sur place pour tracer chaque passage. Le cahier des charges est ajusté dans le temps si vos besoins évoluent, et nous recherchons activement une solution en cas d\'absence de l\'intervenant.',
							'27 € HT/h affiché avant même le devis, frais de gestion et de mise en place annoncés à l\'avance, exemples de budgets chiffrés. Vous savez ce que vous payez avant de nous contacter.',
							'Planning, administratif et coordination gérés par nos soins. Vous gardez un seul contact.',
							'Basée à Saint-Apollinaire, une couverture réelle sur toute la BFC, sans agences fictives.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Directement joignable',
							'Intervenants sélectionnés',
							'Suivi réel',
							'Tarif transparent',
							'Gestion prise en charge',
							'Ancrage régional',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Des preuves plutôt que des slogans',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous préférons ces quelques chiffres, vérifiables, à des formules comme « satisfaction garantie » que nous nous interdisons volontairement d\'employer tant qu\'elles ne reposent pas sur une mesure réelle. Ce que nous nous engageons à faire est décrit, sans superlatif, dans notre page nettoyage professionnel.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'5,0/5',
							'sur Google',
							'24 h',
							'devis transmis',
							'départements',
							'27 €',
							'HT/h, transparent',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => 'blanc',
				'colonnes' => 3,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Ce qui nous distingue, concrètement',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Face à une plateforme de mise en relation',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Une plateforme met en relation et prélève une commission : l\'intervenant change souvent, le cahier des charges n\'existe pas vraiment, et il n\'y a personne à appeler quand quelque chose ne va pas. Nous faisons l\'inverse : un cahier des charges écrit, une interlocutrice identifiée, un cahier de liaison sur place, et un tarif unique annoncé avant le devis. Vous ne gérez pas une succession de prestataires, vous avez un prestataire.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Face à un recrutement direct',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Embaucher un agent d\'entretien suppose de rédiger l\'offre, trier les candidatures, établir le contrat, gérer la paie, les congés et les arrêts, encadrer le travail et acheter le matériel. Notre tarif horaire est plus élevé qu\'un salaire brut, mais il absorbe l\'ensemble de cette charge. Si votre besoin réel est une présence permanente sur site, nous vous dirons franchement qu\'une embauche est plus adaptée.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Le rôle d\'Audrey',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Audrey établit le devis, rédige le cahier des charges avec vous, choisit l\'intervenant, transmet les consignes, suit le cahier de liaison et gère les ajustements. Ce n\'est pas un rôle commercial suivi d\'un transfert vers un service anonyme : c\'est la même personne du premier appel au suivi dans la durée, joignable directement, sans standard ni ticket.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'La gestion administrative',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Une facture mensuelle unique, un devis écrit avant toute intervention, des tarifs annoncés à l\'avance et aucune modification appliquée sans votre accord écrit. Les frais annexes — gestion mensuelle, mise en place, majoration des créneaux particuliers, indemnités kilométriques — sont détaillés sur la page Tarifs et repris sur le devis, jamais découverts sur une facture.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Le suivi dans la durée',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Un cahier de liaison reste sur place et trace chaque passage : ce qui a été fait, ce qui n\'a pas pu l\'être et pourquoi, les remarques et les consommables à renouveler. C\'est un outil simple, mais c\'est la seule façon honnête de savoir ce qui se passe réellement dans vos locaux quand vous n\'êtes pas là.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les limites de nos engagements',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Nous recherchons un intervenant habituel sans le garantir de façon absolue. Nous recherchons activement une solution en cas d\'absence sans promettre un remplacement immédiat systématique. Nous n\'écrivons pas « satisfaction garantie » et n\'affichons aucun chiffre que nous ne pouvons pas justifier. Dire ce que nous ne faisons pas fait partie de ce que nous vendons.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les objections que l\'on nous adresse',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(
							array(
								'question' => '« 27 € HT/h, c\'est plus cher qu\'un salarié »',
								'reponse' => 'Plus cher qu\'un salaire brut horaire, oui. À comparer au coût complet : charges patronales, congés payés, remplacement pendant les absences, matériel, produits, temps de recrutement et d\'encadrement. Sur des volumes de 8 à 25 heures par mois, le prestataire est généralement plus économique — et surtout, il n\'occupe pas votre temps.',
							),
							array(
								'question' => '« Nous avons déjà eu un prestataire, ça s\'est mal passé »',
								'reponse' => 'C\'est le cas de la plupart de nos clients. Dans presque toutes les situations qu\'on nous raconte, deux choses manquaient : un cahier des charges écrit et quelqu\'un à appeler. Ce sont précisément les deux points sur lesquels nous sommes exigeants, avant même de parler de la qualité du nettoyage.',
							),
							array(
								'question' => '« Vous êtes une petite structure, tiendrez-vous dans le temps ? »',
								'reponse' => 'Nous n\'avons qu\'une implantation, à Saint-Apollinaire, et nous ne prétendons pas avoir des agences partout. C\'est justement ce qui permet à Audrey de connaître chaque dossier. En contrepartie, nous refusons les prestations que nous ne pouvons pas assurer correctement, plutôt que d\'accepter et de décevoir.',
							),
							array(
								'question' => '« Comment savoir que le travail a réellement été fait ? »',
								'reponse' => 'Par le cahier de liaison laissé sur place, qui trace chaque passage et mentionne aussi ce qui n\'a pas pu être réalisé. C\'est moins spectaculaire qu\'une application avec des photos, mais c\'est lu, rempli à la main et vérifiable par n\'importe qui dans vos locaux.',
							),
						),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 6,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Vérifier par vous-même',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nos arguments valent surtout s\'ils sont vérifiables. Ces pages détaillent ce que nous venons d\'affirmer.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'La transparence tarifaire27 € HT/h, frais annexes détaillés, exemples chiffrés.',
								'route' => '#/nos-tarifs',
							),
							array(
								'texte' => 'Le suivi, étape par étapeCahier des charges, cahier de liaison, ajustements.',
								'route' => '#/notre-fonctionnement',
							),
							array(
								'texte' => 'Ce qu\'en disent nos clientsRetours de dirigeants, gestionnaires et commerçants.',
								'route' => '#/avis-clients',
							),
							array(
								'texte' => 'Qui est derrière Top-Famille ProUne implantation, une interlocutrice, une organisation.',
								'route' => '#/a-propos',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 7,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Faisons connaissance',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Un devis gratuit, ou simplement un échange sur vos besoins.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ pourquoi-nous (6 sections)\n";

update_option( 'tfp_page_notre-fonctionnement', array(
		'h1' => 'Notre fonctionnement',
		'lede' => array(
			'De la première prise de contact au suivi dans la durée, une organisation claire pour que vous n\'ayez rien à gérer au quotidien.',
			'Ce fonctionnement en cinq étapes est le même pour tous nos clients, quel que soit le type de locaux ou le département. C\'est cette régularité qui nous permet de tenir nos délais de devis et d\'assurer un suivi cohérent, même lorsque votre dossier passe d\'une étape à l\'autre.',
		),
		'hero_alt' => '',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(
							array(
								'numero' => '01',
								'titre' => 'Prise de contact',
								'texte' => 'Vous nous décrivez vos locaux (surface, type d\'activité, effectif présent), vos besoins et vos contraintes d\'horaires, par téléphone ou via le formulaire de devis. Cet échange initial, généralement bref, nous permet déjà d\'orienter la prestation adaptée parmi nos six formules.',
							),
							array(
								'numero' => '02',
								'titre' => 'Analyse du besoin',
								'texte' => 'Nous étudions le volume d\'heures nécessaire selon la surface, la fréquence souhaitée et le niveau d\'exigence de vos locaux (standard ou renforcé pour les espaces recevant du public). C\'est cette étape qui détermine un devis réaliste, plutôt qu\'une estimation automatique.',
							),
							array(
								'numero' => '03',
								'titre' => 'Devis sous 24 h',
								'texte' => 'Vous recevez une proposition claire et chiffrée, basée sur 27 € HT/h, détaillant le volume d\'heures estimé, les frais éventuels de gestion et de mise en place, et l\'organisation envisagée. Sans engagement de votre part.',
							),
							array(
								'numero' => '04',
								'titre' => 'Sélection & mise en place',
								'texte' => 'Nous sélectionnons l\'intervenant le plus adapté à vos locaux, en recherchant autant que possible une personne habituelle qui interviendra durablement chez vous. Le planning est établi avec vous, les modalités d\'accès (clés, badge, code) sont définies et consignées par écrit, et un premier passage de mise en place permet de vérifier que le cahier des charges est bien compris sur le terrain.',
							),
							array(
								'numero' => '05',
								'titre' => 'Suivi & liaison',
								'texte' => 'Un cahier de liaison reste sur place à chaque passage, pour tracer les tâches réalisées et vos remarques éventuelles. Audrey suit la prestation dans la durée, ajuste la fréquence ou le cahier des charges si vos besoins évoluent, et recherche activement une solution en cas d\'absence imprévue de l\'intervenant habituel, sans que ce remplacement puisse être garanti dans tous les cas.',
							),
						),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 3,
				'cartes' => array(
					'padding' => '20px 22px',
					'rayon' => '14px',
					'fond' => 'rgb(255, 255, 255)',
				),
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les informations dont nous avons besoin',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Si vous découvrez le sujet, commencez par notre page nettoyage professionnel : elle explique ce que recouvre une prestation avant même le premier échange.',
							'Plus votre première description est précise, plus le devis est juste. Six éléments suffisent le plus souvent : le type de locaux et leur usage, la surface approximative et le nombre de pièces, le nombre de personnes réellement présentes chaque jour, le nombre de sanitaires et la présence d\'une cuisine, la fréquence souhaitée et les créneaux possibles, enfin les contraintes particulières — accès, alarme, confidentialité, revêtements fragiles, matériel à ne pas toucher. Nous ne demandons rien de plus à ce stade, et aucune information n\'est utilisée à d\'autres fins que l\'établissement du devis.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Transmission des consignes et premier passage',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Une fois le devis accepté, le cahier des charges est transmis à l\'intervenant avant sa première venue, accompagné des modalités d\'accès et des points de vigilance. Le premier passage est un passage de mise en place : il sert autant à réaliser la prestation qu\'à vérifier que le temps prévu correspond à la réalité du terrain. Il n\'est pas rare qu\'il fasse apparaître un ajustement — une pièce plus longue à traiter que prévu, un créneau mal calé, un accès à revoir. Nous préférons corriger à ce moment-là, quand c\'est encore simple, plutôt que de laisser un écart s\'installer.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Modifier, suspendre ou arrêter',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Modifier la prestation',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Un ajustement de périmètre à volume d\'heures constant se met en place rapidement, après un échange avec Audrey. Un changement de volume horaire donne lieu à un devis actualisé, soumis à votre accord avant application. Aucun tarif n\'est modifié sans accord écrit préalable.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Absence de l\'intervenant',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'En cas d\'absence imprévue, nous recherchons activement une solution et vous informons de l\'organisation retenue et de son délai. Nous ne promettons pas un remplacement immédiat dans tous les cas : sur certains créneaux, une information rapide vaut mieux qu\'un engagement intenable.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Suspendre ou arrêter',
						'niveau' => 'h3',
						'grille' => true,
						'textes' => array(
							'Une suspension temporaire — fermeture annuelle, travaux, déménagement — se demande simplement et se reprend à la date que vous fixez. L\'arrêt de la prestation est possible dans les conditions prévues au devis, sans engagement de durée et sans pénalité de sortie.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Faire évoluer le périmètre',
						'niveau' => 'h3',
						'grille' => false,
						'textes' => array(
							'Nouveaux locaux, étage supplémentaire, ouverture d\'un second site, passage du régulier au ponctuel : le cahier des charges est repris et un devis actualisé vous est transmis, selon le même délai de 24 heures que pour une première demande.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Ce que contient le devis →',
								'route' => '#/nos-tarifs',
							),
							array(
								'texte' => 'Les six prestations →',
								'route' => '#/nos-prestations',
							),
							array(
								'texte' => 'Pourquoi nous →',
								'route' => '#/pourquoi-top-famille-pro',
							),
							array(
								'texte' => 'Rédiger un cahier des charges →',
								'route' => '#/article/cahier-des-charges-nettoyage',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Prêt à démarrer ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Un devis gratuit sous 24 h, sans engagement.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ notre-fonctionnement (3 sections)\n";

update_option( 'tfp_page_avis-clients', array(
		'h1' => 'Avis de nos clients',
		'lede' => array(
			'Les retours de professionnels que nous accompagnons en Bourgogne-Franche-Comté. Nous ne publions que des avis authentiques et autorisés.',
		),
		'hero_alt' => '',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(
							'5,0',
							'/5',
							'★★★★★',
							'Sur · avis clients',
							'Google',
							'47',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'« Devis clair reçu le lendemain, sans surprise. Le respect des consignes de confidentialité dans le cabinet a tout de suite été un point fort. »',
							'« Nettoyage de la boutique avant l\'ouverture, vitrines nickel. Les horaires ont été adaptés à nos jours de marché sans discuter. »',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'★★★★★',
							'· ·',
							'Marc V.',
							'Directeur administratif',
							'Chalon-sur-Saône',
							'★★★★★',
							'★★★★★',
						),
						'citations' => array(
							'« Nous avons comparé une embauche et un prestataire. Ce qui a tranché, c\'est le cahier des charges écrit noir sur blanc et le fait de savoir dès le départ ce qui n\'était pas inclus. »',
						),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'★★★★★',
							'Camille R.',
							'· , ·',
							'Dirigeante de PME',
							'Bureaux',
							'Dijon',
							'mars 2026',
							'★★★★★',
							'Thomas L.',
							'· , ·',
							'Responsable de cabinet',
							'Cabinet médical',
							'Besançon',
							'février 2026',
							'★★★★★',
							'Sarah B.',
							'· , ·',
							'Commerçante',
							'Boutique',
							'Dole',
							'février 2026',
							'★★★★★',
							'Nadia M.',
							'· , ·',
							'Gestionnaire de copropriété',
							'Parties communes',
							'Chalon-sur-Saône',
							'janvier 2026',
							'★★★★★',
							'Julien P.',
							'· , ·',
							'Gestionnaire de meublés',
							'Location meublée',
							'Auxerre',
							'janvier 2026',
							'★★★★★',
							'Olivier D.',
							'· , ·',
							'Gérant',
							'Remise en état',
							'Besançon',
							'décembre 2025',
						),
						'citations' => array(
							'« Même intervenante chaque semaine dans nos bureaux, un cahier de liaison sérieux et Audrey qui répond dans l\'heure. On a enfin arrêté de gérer ça en interne. »',
							'« Devis clair reçu le lendemain, sans surprise. Le respect des consignes de confidentialité dans le cabinet a tout de suite été un point fort. »',
							'« Nettoyage de la boutique avant l\'ouverture, vitrines nickel. Les horaires ont été adaptés à nos jours de marché sans discuter. »',
							'« Pour nos copropriétés, le suivi est réel : halls et cages d\'escalier constants, et un remplacement trouvé rapidement pendant les congés. »',
							'« Remises en état entre deux locataires impeccables, avec un contrôle avant chaque arrivée. Réactivité au rendez-vous pour la location meublée. »',
							'« Remise en état ponctuelle après travaux, devis précis et résultat au rendez-vous dans les délais annoncés. Interlocuteur unique appréciable. »',
						),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Un avis ne remplace pas un devis',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le plus utile reste de comparer notre organisation et notre tarif à votre situation réelle.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Nos tarifs27 € HT/h, gestion, mise en place, exemples.',
								'route' => '#/nos-tarifs',
							),
							array(
								'texte' => 'Nos prestationsLe détail par type de local.',
								'route' => '#/nos-prestations',
							),
							array(
								'texte' => 'Pourquoi nousNos preuves, et nos limites assumées.',
								'route' => '#/pourquoi-top-famille-pro',
							),
							array(
								'texte' => 'Votre secteurHuit départements couverts depuis Saint-Apollinaire.',
								'route' => '#/bourgogne-franche-comte',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 6,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'À votre tour ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Un devis gratuit sous 24 h, au tarif de 27 € HT/h.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ avis-clients (5 sections)\n";

update_option( 'tfp_page_a-propos', array(
		'h1' => 'Une entreprise régionale, un visage',
		'lede' => array(
			'Top-Famille Pro est la déclinaison professionnelle de Top-Famille, basée à Saint-Apollinaire, aux portes de Dijon. Nous accompagnons les professionnels de toute la Bourgogne-Franche-Comté pour l\'entretien de leurs locaux.',
			'Notre conviction : la qualité d\'un service tient autant à la propreté qu\'à la fiabilité, à la transparence et à la relation humaine. Un local propre ne suffit pas si le prestataire est injoignable, si l\'intervenant change sans prévenir, ou si le tarif réserve des surprises.',
			'Nous avons construit Top-Famille Pro autour de trois piliers concrets : une sélection rigoureuse des intervenants, un suivi tracé par cahier de liaison, et une interlocutrice unique — Audrey — qui connaît chaque dossier. Cette organisation s\'inspire directement de celle de Top-Famille, construite auprès des particuliers puis adaptée ici aux contraintes propres aux professionnels : horaires d\'activité, confidentialité, accès sécurisé.',
		),
		'hero_alt' => 'Audrey, Top-Famille Pro',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'« Mon rôle, c\'est de rester joignable et de tenir mes engagements. Chaque client sait à qui parler, et sait ce qui a été fait dans ses locaux. »',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Audrey',
							'· Top-Famille Pro',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => '',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Basée à Saint-Apollinaire, nous restons une entreprise régionale, pas une plateforme nationale. Audrey reste joignable directement, sans standard ni ticket à ouvrir.',
							'Un cahier des charges défini avant chaque prestation, un cahier de liaison à chaque passage, et une organisation identique pour tous nos clients, quel que soit le département.',
							'27 € HT/h affiché avant le devis, frais annoncés à l\'avance, exemples de budgets chiffrés. Nous nous interdisons les formulations vagues du type « satisfaction garantie ».',
							'Top-Famille Pro reprend la logique de service qui a fait ses preuves auprès des particuliers avec Top-Famille, adaptée aux exigences propres aux professionnels.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Proximité',
							'Rigueur',
							'Transparence',
							'Filiation Top-Famille',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Qui nous sommes',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Top-Famille Pro est l\'activité dédiée aux professionnels de Top-Famille. Notre métier est l\'entretien de locaux à usage professionnel : bureaux, commerces, cabinets, parties communes de copropriété, locations meublées et interventions ponctuelles de remise en état. Nous ne sommes ni une plateforme de mise en relation, ni un réseau de franchises : une seule structure, une seule implantation, une seule personne responsable de la relation client.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Notre implantation',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous sommes basés à Saint-Apollinaire, aux portes de Dijon, en Côte-d\'Or. C\'est notre unique implantation : nous n\'avons pas d\'agence dans les autres départements et nous ne le prétendons pas. Depuis Saint-Apollinaire, nous intervenons sur les huit départements de la Bourgogne-Franche-Comté. Selon la distance, des indemnités kilométriques peuvent s\'appliquer ; elles sont indiquées sur le devis, avant toute intervention.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Le rôle d\'Audrey',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Audrey est votre interlocutrice du premier appel au suivi dans la durée. Elle établit le devis, rédige le cahier des charges avec vous, choisit l\'intervenant, lui transmet les consignes, suit le cahier de liaison et traite les ajustements. Cela signifie qu\'elle connaît votre dossier sans avoir à le relire, et que vous n\'avez jamais à réexpliquer votre situation à quelqu\'un d\'autre. Cela signifie aussi qu\'elle est parfois en intervention ou en rendez-vous : dans ce cas, elle rappelle.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Le lien avec Top-Famille',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Top-Famille accompagne les particuliers ; Top-Famille Pro reprend la même logique de service pour les professionnels. Ce qui est commun : la sélection des intervenants, le suivi écrit, un interlocuteur identifié, la transparence sur le tarif. Ce qui change : les horaires calés sur une activité, la confidentialité des locaux, la gestion des accès et de l\'alarme, la formalisation d\'un cahier des charges validé avec le client. Les deux activités partagent une organisation, pas un catalogue de prestations.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Un fonctionnement régional',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Travailler à l\'échelle d\'une région avec une seule implantation impose des choix. Nous regroupons les interventions par secteur, nous privilégions les intervenants domiciliés près des locaux à entretenir, et nous acceptons les missions dont nous pouvons réellement assurer la continuité. C\'est aussi pour cette raison que nous refusons certaines demandes trop éloignées ou trop contraintes en horaires : mieux vaut un refus clair qu\'une prestation qui se dégrade au bout de deux mois.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Nos valeurs, traduites en actions',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Une valeur qui ne se traduit pas en action concrète n\'a aucun intérêt. La transparence, chez nous, c\'est un tarif horaire affiché avant même le devis et des frais annexes détaillés. La rigueur, c\'est un cahier des charges écrit et un cahier de liaison rempli à chaque passage. La proximité, c\'est un numéro direct plutôt qu\'un formulaire. L\'honnêteté, c\'est écrire noir sur blanc ce que nous ne réalisons pas, et le dire dès le premier échange plutôt qu\'après la signature.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les limites de notre offre',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Nous n\'intervenons pas en bio-nettoyage hospitalier, en stérilisation, sur les DASRI ni sur du matériel médical. Nous ne réalisons pas de travail en hauteur nécessitant un équipement spécialisé, ni de traitement de l\'amiante, du plomb ou des moisissures étendues. Nous n\'évacuons pas les gravats et déchets de chantier, n\'effectuons pas de petites réparations, ne gérons pas d\'espaces verts et n\'assurons pas de conciergerie. Nous ne garantissons pas non plus un même intervenant à chaque passage : nous recherchons cette continuité et la privilégions autant que possible.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Nous contacter',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Le plus simple reste le téléphone : décrivez vos locaux en quelques minutes et vous saurez immédiatement si nous sommes le bon prestataire. Vous pouvez aussi passer par le formulaire de demande de devis, auquel nous répondons sous 24 heures, ou par e-mail. Le devis est gratuit et sans engagement, et nous vous dirons franchement si votre besoin relève plutôt d\'une embauche directe ou d\'un prestataire spécialisé.',
						),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Page contact',
								'route' => '#/contact',
							),
							array(
								'texte' => 'Pourquoi nous choisir →',
								'route' => '#/pourquoi-top-famille-pro',
							),
							array(
								'texte' => 'Notre fonctionnement →',
								'route' => '#/notre-fonctionnement',
							),
							array(
								'texte' => 'Nos tarifs →',
								'route' => '#/nos-tarifs',
							),
							array(
								'texte' => 'Rejoindre l\'équipe →',
								'route' => '#/recrutement',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 5,
				'fond' => 'primary',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Parlons de vos locaux',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(
							array(
								'texte' => 'Demander mon devis',
								'route' => '#/demande-de-devis',
							),
							array(
								'texte' => 'Nous contacter',
								'route' => '#/contact',
							),
						),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ a-propos (4 sections)\n";

update_option( 'tfp_page_recrutement', array(
		'h1' => 'Rejoindre Top-Famille Pro',
		'lede' => array(
			'Nous recherchons régulièrement des intervenants sérieux et attentifs pour l\'entretien de locaux professionnels en Bourgogne-Franche-Comté. Travailler avec nous, c\'est intégrer une entreprise régionale qui sélectionne, accompagne et respecte ses intervenants.',
		),
		'hero_alt' => 'Intervenant Top-Famille Pro préparant son matériel de nettoyage',
		'sections' => array(
			array(
				'index' => 2,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Les missions que nous confions',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Entretien matinal ou en soirée, hors présence des équipes.',
							'Avant ouverture ou après fermeture, selon les horaires du commerce.',
							'Passages en dehors des heures de consultation, discrétion requise.',
							'Halls, cages d\'escalier et locaux techniques, en journée.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'Bureaux & sièges d\'entreprise',
							'Commerces & showrooms',
							'Cabinets & professions libérales',
							'Copropriétés & parties communes',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 3,
				'fond' => '',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Ce que nous attendons',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(
							'Sérieux et ponctualité sur les créneaux convenus',
							'Discrétion dans des locaux professionnels et parfois confidentiels',
							'Autonomie une fois le cahier des charges transmis',
							'Un signalement honnête de ce qui n\'a pas pu être fait',
						),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
					array(
						'titre' => 'Les étapes de candidature',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(
							'01',
							'Vous envoyez votre candidature et vos disponibilités.',
							'02',
							'Audrey vous recontacte pour un échange sur votre profil et votre secteur.',
							'03',
							'Selon les missions disponibles près de chez vous, une proposition vous est faite.',
						),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
			array(
				'index' => 4,
				'fond' => 'blanc',
				'colonnes' => 1,
				'cartes' => '',
				'liste_grille' => array(
					'colonnes' => 1,
					'tuile' => false,
				),
				'blocs' => array(
					array(
						'titre' => 'Envie de nous rejoindre ?',
						'niveau' => 'h2',
						'grille' => false,
						'textes' => array(
							'Envoyez-nous votre candidature et vos disponibilités. Nous étudions chaque profil avec attention.',
						),
						'liste' => array(),
						'liens' => array(),
						'noms' => array(),
						'citations' => array(),
						'faq' => array(),
						'etapes' => array(),
					),
				),
			),
		),
	) );
echo "  ✓ recrutement (3 sections)\n";

echo "Terminé.\n";

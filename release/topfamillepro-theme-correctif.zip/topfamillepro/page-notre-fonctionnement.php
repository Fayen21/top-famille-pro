<?php
/**
 * Page statique « Notre fonctionnement » (/notre-fonctionnement/) — gabarit dédié (CLAUDE.md §3).
 *
 * Développe les 4 temps réels de PROJECT_INPUTS.md §8, sans invention de délai ou de fréquence
 * opérationnelle non confirmée (CLAUDE.md §5.1).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$site = tfp_site_data();

/*
 * Pas de `FAQPage` sur cette page : la maquette n'y met aucune FAQ visible, et le corps de page
 * est rendu depuis le contenu relevé du prototype. Le gabarit portait jusqu'ici quatre questions
 * déclarées en données structurées mais absentes de l'écran — contraire à CLAUDE.md §8 et aux
 * règles de Google sur les résultats enrichis, qui exigent que le balisage décrive un contenu que
 * le visiteur voit. Vérifié en continu par tools/audit-jsonld.mjs.
 *
 * Les quatre étapes et les quatre questions qui vivaient ici en dur sont devenues du contenu
 * relevé (bin/seed-fidelite-pages.php) : les garder aurait produit deux sources pour un même écran.
 */
$schema = array();

tfp_seo(
	array(
		'title'       => 'Notre fonctionnement, du devis au suivi | ' . $site['brand_name'],
		'description' => 'Premier échange, devis, sélection de l\'intervenant et suivi : les étapes d\'une prestation d\'entretien chez Top-Famille Pro.',
		'type'        => 'website',
		'robots'      => 'index,follow',
		'breadcrumb'  => array(
			array( 'label' => 'Accueil', 'url' => home_url( '/' ) ),
			array( 'label' => 'Notre fonctionnement', 'url' => null ),
		),
		'schema'      => $schema,
	)
);

get_header();

/*
 * Corps de page rendu par le composant commun : le contenu vient de la maquette Claude Design,
 * relevé par tools/generate-pages.mjs et stocké en option (CLAUDE.md §3 — page WordPress
 * classique, sans champs ACF). L'ordre des sections et leur fond sont ceux du prototype.
 */
$page = tfp_static_page_data( 'notre-fonctionnement' );
?>
<div class="tfp-container">
	<?php tfp_breadcrumb( tfp_seo()['breadcrumb'] ); ?>
</div>

<?php
/*
 * Rembourrage de l'en-tête relevé sur la maquette. `.tfp-section--tight` posait
 * clamp(30px, 4vw, 52px) des deux côtés — 104 px à 1440 px contre 88 relevés.
 */
?>
<section class="tfp-container tfp-section--tight" style="--tfp-bande-haut:clamp(26px, 4vw, 48px);--tfp-bande-bas:clamp(28px, 3vw, 40px)">
	<div class="tfp-hero__eyebrow">
		<?php
		/*
		 * PAS de badge région dans ce hero — relevé sur la maquette (G26 §8/§9).
		 *
		 * Le prototype ne pose ce badge que sur les pages qui parlent d'un territoire : la page
		 * région, les huit départements, les dix-huit villes, les six prestations et la page
		 * tarifs. Les pages institutionnelles — à propos, pourquoi nous, notre fonctionnement,
		 * avis, index des prestations, index des zones, recrutement — n'en portent pas. Le thème
		 * l'ajoutait sur les sept, soit un composant de 35 px et une rangée de plus au-dessus de
		 * chaque H1, ce qui décalait tout le hero. Trois de ces routes en sortaient de la plage de
		 * fidélité au relevé de base.
		 */
		?>
		<?php tfp_google_rating_badge( 'nu' ); ?>
	</div>
	<h1><?php echo esc_html( $page['h1'] ); ?></h1>
	<?php
	/*
	 * Le prototype ne pose qu'UN lède par en-tête : les paragraphes d'introduction suivants y sont
	 * écrits en 16 px / 1,6, un cran sous le premier. Répéter la classe du lède donnait deux
	 * paragraphes de même poids — la hiérarchie voulue disparaissait, et l'en-tête gagnait
	 * une cinquantaine de pixels à 1440 px.
	 */
	foreach ( $page['lede'] as $rang => $lede ) :
		?>
		<p class="<?php echo 0 === $rang ? 'tfp-section__lede' : 'tfp-section__sublede'; ?>"><?php echo esc_html( $lede ); ?></p>
		<?php
	endforeach;
	?>
	<div class="tfp-action-row" style="margin-top:24px">
		<?php
		tfp_button( array( 'label' => 'Demander mon devis', 'href' => home_url( '/demande-de-devis/' ), 'variant' => 'primary' ) );
		tfp_button( array( 'label' => '☎ Appeler ' . explode( ' ', $site['manager'] )[0], 'href' => 'tel:' . $site['phone_href'], 'variant' => 'secondary' ) );
		?>
	</div>
</section>

<?php get_template_part( 'template-parts/components/static-blocks', null, array( 'key' => 'notre-fonctionnement' ) ); ?>

<?php get_footer(); ?>

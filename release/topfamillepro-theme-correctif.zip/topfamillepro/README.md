# Top-Famille Pro — thème enfant (correctif fidélité production)

Thème enfant WordPress pour le site professionnel Top-Famille Pro (SARL TOP-ENTREPRISE),
basé sur le thème parent **GeneratePress**.

## Ce ZIP

Version corrective — `Version: 0.5.0` (voir `style.css`). Corrige, par rapport au premier paquet
de livraison (phase 7) :

- favicon absent (aucune balise `<link rel="icon">` n'était émise) ;
- aucune image sur les 6 pages de prestation individuelles ;
- image Open Graph inadaptée (logo seul à 140 px au lieu d'un visuel 1200×630) ;
- tarif unique 27,00 € HT/h (remplace l'ancienne grille à trois montants) ;
- pages de zone ne maillant qu'une seule prestation sur six ;
- cascade de polices fragile face à un CSS GeneratePress chargé après le thème enfant, logo du
  header sous-dimensionné (~68 px au lieu de 120–155 px) ;
- date des articles au format anglais (« août 9, 2026 ») ;
- mentions légales : hébergeur et directrice de la publication désormais renseignés, plus aucun
  `[À COMPLÉTER]`.

Voir `docs/AUDIT-PRODUCTION.md` du dépôt source pour le diagnostic complet ayant motivé ce
correctif — la cause principale des symptômes signalés en production (absence totale d'images,
police différente, pages vides, routes en 404) n'est pas dans ce thème : le site en ligne ne
faisait tourner aucun code de ce dépôt (thème actif constaté : `V1top-famille-pro`, jamais
présent dans l'historique de ce projet).

## Installation

1. WordPress avec le thème **GeneratePress** déjà installé et activé (thème parent).
2. Extension **Advanced Custom Fields** (gratuite) installée et activée.
3. Apparence → Thèmes → Ajouter un thème → Téléverser un thème → sélectionner ce ZIP → Installer.
4. Activer le thème enfant « Top-Famille Pro ».
5. Installer et exécuter le plugin d'installation de contenu (ZIP séparé) pour créer les 53 pages.
6. Réglages → Permaliens → Enregistrer les modifications (sans rien changer) pour activer les
   routes des prestations et zones.

Procédure complète, pas à pas, avec les chemins exacts du gestionnaire de fichiers Hostinger :
voir `release/GUIDE-DEPLOIEMENT-HOSTINGER.md` du dépôt source, section correctif.

## Ce que ce thème ne contient pas

- Le cœur WordPress, ni aucun plugin (GeneratePress, ACF) : à installer séparément.
- Les uploads WordPress (médias envoyés depuis l'administration).
- Le contenu (pages, prestations, zones, articles) : fourni par le plugin d'installation de
  contenu, dans un ZIP séparé.

## Structure

- `style.css` — déclaration du thème enfant (obligatoire pour WordPress).
- `functions.php`, `includes/` — logique PHP (SEO, ACF, formulaire, données du site).
- `header.php`, `footer.php`, `front-page.php`, `page-*.php`, `single-*.php`, `404.php` — gabarits.
- `template-parts/` — fragments réutilisables (header, footer, sections d'accueil).
- `assets/dist/` — CSS, JS et images déjà compilés (AVIF/WebP/JPEG, polices auto-hébergées).
